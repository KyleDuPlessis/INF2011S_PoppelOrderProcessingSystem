﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.Report
{
    public class ReportItem
    {
        #region Data Members
        private int productID;
        private string orderID;
        public string rackNumber;
        public string description;
        private string quantity;
        #endregion

        #region Properties
        public int ProductID
        {
            get { return productID; }
            set { productID = value; }
        }
        
        public string OrderID
        {
            get { return orderID; }
            set { orderID = value; } 
        }

        public string RackNumber
        {
            get { return rackNumber; }
            set { rackNumber = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        
        public string Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }
        #endregion

        #region Constructor
        public ReportItem()
        {
            ProductID=0;
            Quantity = "";
            Description = "";
            RackNumber="";
            OrderID="";
        }
        #endregion
    }
}
