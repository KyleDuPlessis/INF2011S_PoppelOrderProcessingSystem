﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Poppel.Domain;
using System.Collections.ObjectModel;
using Poppel.Order;
using Poppel.Database;

namespace Poppel.Report
{
    public class PickingListReport
    {
        #region Data Members
        private PoppelDatabase pd;
        public Collection<ReportItem> productToBePicked;
        #endregion

        #region Properties
        public Collection<ReportItem> ProductToBePicked
        {
            get { return productToBePicked; }
            set { productToBePicked = value; }
        }
        #endregion

        #region Constructor
        public PickingListReport() : base()
        {
            this.ProductToBePicked = new Collection<ReportItem>();
            pd = new PoppelDatabase();
        }
        #endregion

        public Collection<ReportItem> GetOrderProducts(DateTime date)
        {
            ProductToBePicked = pd.ReadOrderItem(date);
            return ProductToBePicked;
        }
    }
}