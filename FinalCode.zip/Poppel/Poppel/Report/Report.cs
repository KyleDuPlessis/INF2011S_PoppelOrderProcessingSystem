﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.Report
{
    public class Report
    {
        #region Data Members
        private string id;
        private string generatedBy;
        private DateTime date;
        private string title;
        #endregion

        #region Properties
        public string ID
        {
            get { return id; }
            set { id = value; }
        }
        
        public string GeneratedBy
        {
            get { return generatedBy; }
            set { generatedBy = value; }
        }
        
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }
        
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
        #endregion

        #region Constructors
        public Report(string id, string generatedBy, DateTime date, string title)
        {
            this.ID = id;
            this.GeneratedBy = generatedBy;
            this.Date = date;
            this.Title = title;
        }

        public Report()
        {
            ID = "";
            Date = DateTime.Now;// The current date
            GeneratedBy = "";
            Title = "";
        }
        #endregion
    }
}
