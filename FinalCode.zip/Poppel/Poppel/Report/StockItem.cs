﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.Report
{
    public class StockItem
    {
        #region Data Members
        private string itemExpiryDate;
        private string itemRackNumber;
        private string itemNumberInStock;
        private string productReference;
        #endregion

        #region Properties
        public string ItemExpiryDate
        {
            get {  return itemExpiryDate; }
            set { itemExpiryDate = value; }
        }

        public string ItemRackNumber
        {
            get { return itemRackNumber; }
            set { itemRackNumber = value; }
        }

        public string ItemNumberInStock
        {
            get { return itemNumberInStock; }
            set { itemNumberInStock = value; }
        }

        public string ProductReference
        {
            get { return productReference; }
            set { productReference = value; }
        }
        #endregion

        #region Constructors
        public StockItem(string expiryDate, string rackNumber, string numberInStock, string productRef)
        {
            this.ItemExpiryDate = expiryDate;
            this.ItemRackNumber = rackNumber;
            this.ItemNumberInStock = itemNumberInStock;
            this.ProductReference = productReference;
        }

        public StockItem()
        {
            this.ItemExpiryDate = "";
            this.ItemRackNumber = "";
            this.ItemNumberInStock = "";
            this.ProductReference = "";
        }
        #endregion
    }
}
