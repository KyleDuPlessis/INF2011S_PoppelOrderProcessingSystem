﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.Order
{
    public class Delivery
    {
        #region Data Members
        private DateTime startDeliveryDate;
        private DateTime endDeliveryDate;
        #endregion

        #region Properties
        public DateTime StartDeliveryDate
        {
            get { return startDeliveryDate; }
            set { startDeliveryDate = value; }
        }
        public DateTime EndDeliveryDate
        {
            get { return endDeliveryDate; }
            set { endDeliveryDate = value; }
        }
        #endregion
    }
}
