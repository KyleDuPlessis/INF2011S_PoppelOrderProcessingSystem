﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Poppel.Order;
using Poppel.Domain;
using System.IO;
namespace Poppel.Order
{
   public class OrderItemForm
   {
        #region Data Members
        private int id;
        private OrderItem refOrderItem;
        private FlowLayoutPanel productPanel;
        private Label lblPicture = new Label();
        private Label lblProductDescription;
        private Label lblNumberInStock = new Label();
        private CheckBox chkSimilarFilter;
        private Label lblCost;
        private Label lblQuantity;
        private NumericUpDown nudOrderQuantity;
        private Button btnPlaceOrder;
        private Label lblSpacer;
        #endregion

        #region Properties
        public OrderItem RefOrderItem
        {
            get { return refOrderItem; }
            set { refOrderItem = value; }
        }

        public int ID
        {
            get { return id; }
            set { id = value; }
        }    

        public FlowLayoutPanel ProductPanel
        {
            get { return productPanel; }
            set { productPanel = value; }
        }

        public Label PictureLabel
        {
            get { return lblPicture; }
            set { lblPicture = value; }
        }

        public Label ProductDescriptionLabel
        {
            get { return lblProductDescription; }
            set { lblProductDescription = value; }
        }

        public Label NumberInStockLabel
        {
            get { return lblNumberInStock; }
            set { lblNumberInStock = value; }
        }

        public CheckBox SimilarFilterCheckBox
        {
            get { return chkSimilarFilter; }
            set { chkSimilarFilter = value; }
        }

        public Label CostLabel
        {
            get { return lblCost; }
            set { lblCost = value; }
        }

        public Label QuantityLabel
        {
            get { return lblQuantity; }
            set { lblQuantity = value; }
        }

        public NumericUpDown OrderQuantityNumericUpDown
        {
            get { return nudOrderQuantity; }
            set { nudOrderQuantity = value; }
        }

        public Button PlaceOrderButton
        {
            get { return btnPlaceOrder; }
            set { btnPlaceOrder = value; }
        }

        public Label SpacerLabel
        {
            get { return lblSpacer; }
            set { lblSpacer = value; }
        }
        #endregion

        #region Constructor
        public OrderItemForm(OrderItem orderItem)
        {
            productPanel = new FlowLayoutPanel();
            lblPicture = new Label();
            lblProductDescription = new Label();
            lblNumberInStock = new Label();
            chkSimilarFilter = new CheckBox();
            lblCost = new Label();
            lblQuantity = new Label();
            nudOrderQuantity = new NumericUpDown();
            btnPlaceOrder = new Button();
            lblSpacer = new Label();

            RefOrderItem = orderItem;
            ID = orderItem.Product.ID;

            ProductPanel.Width = 200;
            ProductPanel.Height = 270;
            ProductPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            
            PictureLabel.Width = 200;
            PictureLabel.Height = 150;
            string path = "Assets/" + orderItem.Product.ProductCode + ".png";
            FileInfo file = new FileInfo(path);
            if(file.Exists)
            {
                Bitmap pictureBitmap = new Bitmap(path);
                PictureLabel.Image = pictureBitmap;
            }

            ProductPanel.Controls.Add(PictureLabel);

            ProductDescriptionLabel = new Label();
            ProductDescriptionLabel.Width = ProductPanel.Width;
            ProductDescriptionLabel.Text = orderItem.Product.Description;
            ProductDescriptionLabel.TextAlign = ContentAlignment.TopCenter;
            ProductPanel.Controls.Add(ProductDescriptionLabel);
            
            NumberInStockLabel.Text = "Quantity In Stock: " + orderItem.Product.NumberInStock;
            NumberInStockLabel.AutoSize = true;
            NumberInStockLabel.Width = ProductPanel.Width;

            SimilarFilterCheckBox.Width = ProductPanel.Width;
            SimilarFilterCheckBox.Text = "Filter to alternatives";
            SimilarFilterCheckBox.Tag = orderItem.Product.ID;
            
            ProductPanel.Controls.Add(NumberInStockLabel);
            ProductPanel.Controls.Add(SimilarFilterCheckBox);
            
            CostLabel = new Label();
            CostLabel.Text = "R " + string.Format("{0:0.00}", orderItem.Product.Price);
            CostLabel.Width = ProductPanel.Width;
            CostLabel.BackColor = Color.NavajoWhite;
            CostLabel.TextAlign = ContentAlignment.MiddleCenter;
            CostLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            CostLabel.Width = ProductPanel.Width;
            ProductPanel.Controls.Add(CostLabel);
            
            QuantityLabel.Text = "Quantity:";
            QuantityLabel.TextAlign = ContentAlignment.MiddleCenter;
            QuantityLabel.Size = new System.Drawing.Size(49, 20);
            ProductPanel.Controls.Add(QuantityLabel);
            
            OrderQuantityNumericUpDown.Minimum = 1;
            OrderQuantityNumericUpDown.Width = 35;
            OrderQuantityNumericUpDown.Tag = orderItem.Product.ID;
            OrderQuantityNumericUpDown.Maximum = orderItem.Product.NumberInStock;
            ProductPanel.Controls.Add(OrderQuantityNumericUpDown);
           
            PlaceOrderButton.Tag = orderItem.Product.ID;
            PlaceOrderButton.Text = "Add";
            
            SpacerLabel.Width = 15;
            ProductPanel.Controls.Add(SpacerLabel);
            ProductPanel.Controls.Add(PlaceOrderButton);

            if(orderItem.Product.NumberInStock<=0)
            {
                btnPlaceOrder.Enabled = false;
                nudOrderQuantity.Enabled = false;
            }
        }
        #endregion
   }
}
