﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace Poppel.Order
{
    public class RemoveOrderItem
    {
        #region Data Members
        private string orderNumber;
        private string orderDatePlaced;
        #endregion

        #region Properties
        public string OrderNumber
        {
            get { return orderNumber; }
            set { orderNumber = value; }
        }

        public string OrderDatePlaced
        {
            get { return orderDatePlaced; }
            set { orderDatePlaced = value; }
        }
        #endregion

        #region Constructor
        public RemoveOrderItem()
        {
            orderNumber = "";
            orderDatePlaced = "";
        }
        #endregion
    }
}
