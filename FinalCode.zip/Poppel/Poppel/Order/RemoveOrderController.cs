﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using Poppel.Report;
using Poppel.Database;
using Poppel.CustomerMangement;

namespace Poppel.Order
{
    public class RemoveOrderController
    {
        #region Data Members
        public Collection<RemoveOrderItem> products;
        PoppelDatabase pd = new PoppelDatabase();
        private CustomerManangementController customerManagementController;
        #endregion

        #region Properties
        public CustomerManangementController CustomerManagementController
        {
            get { return customerManagementController; }
            set { customerManagementController = value; }
        }
        #endregion

        #region Constructor
        public RemoveOrderController(CustomerManangementController customerManagementController)
        {
            this.customerManagementController = customerManagementController;
            products = new Collection<RemoveOrderItem>();
        }
        #endregion

        public Collection<RemoveOrderItem> GetOrders()
        {
            products = pd.GetOrders(CustomerManagementController.Customer.ID);
            return products;
        }

        public void Delete(int orderID)
        {          
            pd.DeleteOrder(orderID, CustomerManagementController.Customer.ID);
        }
    }
}
