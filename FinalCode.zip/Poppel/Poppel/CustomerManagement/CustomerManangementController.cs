﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Poppel.PresentationLayer;
using Poppel.Domain;
using Poppel.Database;

namespace Poppel.CustomerMangement
{
    public class CustomerManangementController
    {
        #region Data Members
        private PoppelDatabase database = new PoppelDatabase();
        private Customer customer;
        private Employee employee;
        #endregion

        #region Properties
        public Employee Employee
        {
            get { return employee; }
            set { employee = value; }
        }

        public Customer Customer
        {
            get { return customer; }
            set { customer = value; }
        }
        #endregion

        public Customer SearchCustomerByCustomerNumber(string id)
        {
            return database.ReadCustomersByCustomerNumber(id);
        }

        public void EditCustomer(Customer customer)
        {
            database.EditCustomer(customer);
        }
        public void AddCustomer(Customer customer)
        {
            database.AddCustomer(customer);
        }

        public string GenerateID(string firstName, string lastName)
        {
            bool generated = false;
            string customerCode="";
            Random random = new Random();          

            if (lastName.Length >= 3)
            {
                customerCode += lastName.Substring(0, 3);
            }
            else
            {
                customerCode += lastName.Substring(0, lastName.Length);
                for (int i = 0; i < 3 - lastName.Length; i++)
                {

                    int num = random.Next(0, 26); // Zero to 25
                    char character = (char)('a' + num);
                    customerCode += character;
                }
            }
            if (firstName.Length >= 3)
            {
                customerCode += firstName.Substring(0, 3);
            }
            else
            {
                customerCode += firstName.Substring(0, firstName.Length);
                for (int i = 0; i < 3 - firstName.Length; i++)
                {
                    int num = random.Next(0, 26); // Zero to 25
                    char character = (char)('a' + num);
                    customerCode += character;
                }
            }
            int number = 0;
            while(!generated)
            {
                number++;
                if(number==1000)
                {
                    return null;
                }
                string testCode = "" + number;
                for (int i = 0; i <= 3 - testCode.Length; i++)
                {
                    testCode = "0" + testCode;
                }
                testCode = customerCode +""+ testCode;
                testCode = testCode.ToLower();
                if(!database.DoesKeyExist(testCode))
                {
                    generated = true;
                    customerCode = testCode;
                }
            }
            return customerCode;
        }
    }
}
