﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Poppel.Database;
using Poppel.Domain;

namespace Poppel.Login
{
    public class LoginController
    {
        #region Data Members
        private PoppelDatabase database = new PoppelDatabase();
        #endregion

        public Employee Login(string username, string password)
        {
            return database.Login(username, password);
        }
    }
}
