﻿namespace Poppel.PresentationLayer
{
    partial class OrderConfirmation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gboOrderDetails = new System.Windows.Forms.GroupBox();
            this.lblOrdTotal = new System.Windows.Forms.Label();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.lblMarketingClerk = new System.Windows.Forms.Label();
            this.lblOrderTotal = new System.Windows.Forms.Label();
            this.lblOrdID = new System.Windows.Forms.Label();
            this.lblOrdDate = new System.Windows.Forms.Label();
            this.lblOrderDate = new System.Windows.Forms.Label();
            this.lblOrderID = new System.Windows.Forms.Label();
            this.lblOrderSummary = new System.Windows.Forms.Label();
            this.gboItemsOrdered = new System.Windows.Forms.GroupBox();
            this.lstItemsOrdered = new System.Windows.Forms.ListView();
            this.gboDeliveryDetails = new System.Windows.Forms.GroupBox();
            this.lblDeliveryTime = new System.Windows.Forms.Label();
            this.txtDeliveryAddress = new System.Windows.Forms.TextBox();
            this.lblDeliveryAddress = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.lblTo = new System.Windows.Forms.Label();
            this.lblStartDate = new System.Windows.Forms.Label();
            this.lblEstimatedDeliveryDates = new System.Windows.Forms.Label();
            this.btnConfirmOrder = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gboCustomerDetails = new System.Windows.Forms.GroupBox();
            this.lblCustID = new System.Windows.Forms.Label();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.lblCustName = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.pbPoppelLogo = new System.Windows.Forms.PictureBox();
            this.lblRepID = new System.Windows.Forms.Label();
            this.lblReportID = new System.Windows.Forms.Label();
            this.gboOrderDetails.SuspendLayout();
            this.gboItemsOrdered.SuspendLayout();
            this.gboDeliveryDetails.SuspendLayout();
            this.gboCustomerDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // gboOrderDetails
            // 
            this.gboOrderDetails.Controls.Add(this.lblOrdTotal);
            this.gboOrderDetails.Controls.Add(this.lblEmployeeName);
            this.gboOrderDetails.Controls.Add(this.lblMarketingClerk);
            this.gboOrderDetails.Controls.Add(this.lblOrderTotal);
            this.gboOrderDetails.Controls.Add(this.lblOrdID);
            this.gboOrderDetails.Controls.Add(this.lblOrdDate);
            this.gboOrderDetails.Controls.Add(this.lblOrderDate);
            this.gboOrderDetails.Controls.Add(this.lblOrderID);
            this.gboOrderDetails.Location = new System.Drawing.Point(12, 195);
            this.gboOrderDetails.Name = "gboOrderDetails";
            this.gboOrderDetails.Size = new System.Drawing.Size(385, 125);
            this.gboOrderDetails.TabIndex = 0;
            this.gboOrderDetails.TabStop = false;
            this.gboOrderDetails.Text = "Order Details";
            // 
            // lblOrdTotal
            // 
            this.lblOrdTotal.AutoSize = true;
            this.lblOrdTotal.Location = new System.Drawing.Point(102, 104);
            this.lblOrdTotal.Name = "lblOrdTotal";
            this.lblOrdTotal.Size = new System.Drawing.Size(72, 13);
            this.lblOrdTotal.TabIndex = 12;
            this.lblOrdTotal.Text = "<Order Total>";
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Location = new System.Drawing.Point(102, 45);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(96, 13);
            this.lblEmployeeName.TabIndex = 11;
            this.lblEmployeeName.Text = "<Employee Name>";
            // 
            // lblMarketingClerk
            // 
            this.lblMarketingClerk.AutoSize = true;
            this.lblMarketingClerk.Location = new System.Drawing.Point(8, 45);
            this.lblMarketingClerk.Name = "lblMarketingClerk";
            this.lblMarketingClerk.Size = new System.Drawing.Size(84, 13);
            this.lblMarketingClerk.TabIndex = 10;
            this.lblMarketingClerk.Text = "Marketing Clerk:";
            // 
            // lblOrderTotal
            // 
            this.lblOrderTotal.AutoSize = true;
            this.lblOrderTotal.Location = new System.Drawing.Point(29, 104);
            this.lblOrderTotal.Name = "lblOrderTotal";
            this.lblOrderTotal.Size = new System.Drawing.Size(63, 13);
            this.lblOrderTotal.TabIndex = 8;
            this.lblOrderTotal.Text = "Order Total:";
            // 
            // lblOrdID
            // 
            this.lblOrdID.AutoSize = true;
            this.lblOrdID.Location = new System.Drawing.Point(102, 20);
            this.lblOrdID.Name = "lblOrdID";
            this.lblOrdID.Size = new System.Drawing.Size(59, 13);
            this.lblOrdID.TabIndex = 6;
            this.lblOrdID.Text = "<Order ID>";
            // 
            // lblOrdDate
            // 
            this.lblOrdDate.AutoSize = true;
            this.lblOrdDate.Location = new System.Drawing.Point(102, 75);
            this.lblOrdDate.Name = "lblOrdDate";
            this.lblOrdDate.Size = new System.Drawing.Size(71, 13);
            this.lblOrdDate.TabIndex = 5;
            this.lblOrdDate.Text = "<Order Date>";
            // 
            // lblOrderDate
            // 
            this.lblOrderDate.AutoSize = true;
            this.lblOrderDate.Location = new System.Drawing.Point(30, 75);
            this.lblOrderDate.Name = "lblOrderDate";
            this.lblOrderDate.Size = new System.Drawing.Size(62, 13);
            this.lblOrderDate.TabIndex = 2;
            this.lblOrderDate.Text = "Order Date:";
            // 
            // lblOrderID
            // 
            this.lblOrderID.AutoSize = true;
            this.lblOrderID.Location = new System.Drawing.Point(42, 20);
            this.lblOrderID.Name = "lblOrderID";
            this.lblOrderID.Size = new System.Drawing.Size(50, 13);
            this.lblOrderID.TabIndex = 1;
            this.lblOrderID.Text = "Order ID:";
            // 
            // lblOrderSummary
            // 
            this.lblOrderSummary.AutoSize = true;
            this.lblOrderSummary.Font = new System.Drawing.Font("Poor Richard", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOrderSummary.ForeColor = System.Drawing.Color.Orchid;
            this.lblOrderSummary.Location = new System.Drawing.Point(322, 33);
            this.lblOrderSummary.Name = "lblOrderSummary";
            this.lblOrderSummary.Size = new System.Drawing.Size(251, 33);
            this.lblOrderSummary.TabIndex = 35;
            this.lblOrderSummary.Text = "Order Confirmation";
            // 
            // gboItemsOrdered
            // 
            this.gboItemsOrdered.Controls.Add(this.lstItemsOrdered);
            this.gboItemsOrdered.Location = new System.Drawing.Point(12, 326);
            this.gboItemsOrdered.Name = "gboItemsOrdered";
            this.gboItemsOrdered.Size = new System.Drawing.Size(774, 233);
            this.gboItemsOrdered.TabIndex = 36;
            this.gboItemsOrdered.TabStop = false;
            this.gboItemsOrdered.Text = "Items Ordered";
            // 
            // lstItemsOrdered
            // 
            this.lstItemsOrdered.Location = new System.Drawing.Point(6, 19);
            this.lstItemsOrdered.MultiSelect = false;
            this.lstItemsOrdered.Name = "lstItemsOrdered";
            this.lstItemsOrdered.Size = new System.Drawing.Size(762, 208);
            this.lstItemsOrdered.TabIndex = 22;
            this.lstItemsOrdered.UseCompatibleStateImageBehavior = false;
            // 
            // gboDeliveryDetails
            // 
            this.gboDeliveryDetails.Controls.Add(this.lblDeliveryTime);
            this.gboDeliveryDetails.Controls.Add(this.txtDeliveryAddress);
            this.gboDeliveryDetails.Controls.Add(this.lblDeliveryAddress);
            this.gboDeliveryDetails.Controls.Add(this.lblEndDate);
            this.gboDeliveryDetails.Controls.Add(this.lblTo);
            this.gboDeliveryDetails.Controls.Add(this.lblStartDate);
            this.gboDeliveryDetails.Controls.Add(this.lblEstimatedDeliveryDates);
            this.gboDeliveryDetails.Location = new System.Drawing.Point(403, 121);
            this.gboDeliveryDetails.Name = "gboDeliveryDetails";
            this.gboDeliveryDetails.Size = new System.Drawing.Size(383, 199);
            this.gboDeliveryDetails.TabIndex = 8;
            this.gboDeliveryDetails.TabStop = false;
            this.gboDeliveryDetails.Text = "Delivery Details";
            // 
            // lblDeliveryTime
            // 
            this.lblDeliveryTime.AutoSize = true;
            this.lblDeliveryTime.Location = new System.Drawing.Point(33, 42);
            this.lblDeliveryTime.Name = "lblDeliveryTime";
            this.lblDeliveryTime.Size = new System.Drawing.Size(304, 13);
            this.lblDeliveryTime.TabIndex = 13;
            this.lblDeliveryTime.Text = "Orders will be delivered between 8:00 and 17:00 on weekdays.";
            // 
            // txtDeliveryAddress
            // 
            this.txtDeliveryAddress.BackColor = System.Drawing.SystemColors.Control;
            this.txtDeliveryAddress.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtDeliveryAddress.Location = new System.Drawing.Point(128, 74);
            this.txtDeliveryAddress.Multiline = true;
            this.txtDeliveryAddress.Name = "txtDeliveryAddress";
            this.txtDeliveryAddress.Size = new System.Drawing.Size(239, 98);
            this.txtDeliveryAddress.TabIndex = 12;
            this.txtDeliveryAddress.TabStop = false;
            // 
            // lblDeliveryAddress
            // 
            this.lblDeliveryAddress.AutoSize = true;
            this.lblDeliveryAddress.Location = new System.Drawing.Point(33, 74);
            this.lblDeliveryAddress.Name = "lblDeliveryAddress";
            this.lblDeliveryAddress.Size = new System.Drawing.Size(89, 13);
            this.lblDeliveryAddress.TabIndex = 10;
            this.lblDeliveryAddress.Text = "Delivery Address:";
            // 
            // lblEndDate
            // 
            this.lblEndDate.AutoSize = true;
            this.lblEndDate.Location = new System.Drawing.Point(236, 20);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(49, 13);
            this.lblEndDate.TabIndex = 9;
            this.lblEndDate.Text = "EndDate";
            // 
            // lblTo
            // 
            this.lblTo.AutoSize = true;
            this.lblTo.Location = new System.Drawing.Point(214, 20);
            this.lblTo.Name = "lblTo";
            this.lblTo.Size = new System.Drawing.Size(16, 13);
            this.lblTo.TabIndex = 8;
            this.lblTo.Text = "to";
            // 
            // lblStartDate
            // 
            this.lblStartDate.AutoSize = true;
            this.lblStartDate.Location = new System.Drawing.Point(155, 20);
            this.lblStartDate.Name = "lblStartDate";
            this.lblStartDate.Size = new System.Drawing.Size(52, 13);
            this.lblStartDate.TabIndex = 7;
            this.lblStartDate.Text = "StartDate";
            // 
            // lblEstimatedDeliveryDates
            // 
            this.lblEstimatedDeliveryDates.AutoSize = true;
            this.lblEstimatedDeliveryDates.Location = new System.Drawing.Point(6, 20);
            this.lblEstimatedDeliveryDates.Name = "lblEstimatedDeliveryDates";
            this.lblEstimatedDeliveryDates.Size = new System.Drawing.Size(128, 13);
            this.lblEstimatedDeliveryDates.TabIndex = 0;
            this.lblEstimatedDeliveryDates.Text = "Estimated Delivery Dates:";
            // 
            // btnConfirmOrder
            // 
            this.btnConfirmOrder.Location = new System.Drawing.Point(686, 565);
            this.btnConfirmOrder.Name = "btnConfirmOrder";
            this.btnConfirmOrder.Size = new System.Drawing.Size(100, 30);
            this.btnConfirmOrder.TabIndex = 37;
            this.btnConfirmOrder.Text = "Confirm Order";
            this.btnConfirmOrder.UseVisualStyleBackColor = true;
            this.btnConfirmOrder.Click += new System.EventHandler(this.btnConfirmOrder_Click);
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(0, 0);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 23);
            this.btnBack.TabIndex = 59;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(595, 565);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(85, 30);
            this.btnCancel.TabIndex = 39;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // gboCustomerDetails
            // 
            this.gboCustomerDetails.Controls.Add(this.lblCustID);
            this.gboCustomerDetails.Controls.Add(this.lblCustomerID);
            this.gboCustomerDetails.Controls.Add(this.lblCustName);
            this.gboCustomerDetails.Controls.Add(this.lblCustomerName);
            this.gboCustomerDetails.Location = new System.Drawing.Point(12, 121);
            this.gboCustomerDetails.Name = "gboCustomerDetails";
            this.gboCustomerDetails.Size = new System.Drawing.Size(385, 68);
            this.gboCustomerDetails.TabIndex = 40;
            this.gboCustomerDetails.TabStop = false;
            this.gboCustomerDetails.Text = "Customer Details";
            // 
            // lblCustID
            // 
            this.lblCustID.AutoSize = true;
            this.lblCustID.Location = new System.Drawing.Point(125, 20);
            this.lblCustID.Name = "lblCustID";
            this.lblCustID.Size = new System.Drawing.Size(77, 13);
            this.lblCustID.TabIndex = 10;
            this.lblCustID.Text = "<Customer ID>";
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(51, 20);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(68, 13);
            this.lblCustomerID.TabIndex = 9;
            this.lblCustomerID.Text = "Customer ID:";
            // 
            // lblCustName
            // 
            this.lblCustName.AutoSize = true;
            this.lblCustName.Location = new System.Drawing.Point(125, 42);
            this.lblCustName.Name = "lblCustName";
            this.lblCustName.Size = new System.Drawing.Size(94, 13);
            this.lblCustName.TabIndex = 8;
            this.lblCustName.Text = "<Customer Name>";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(34, 42);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(85, 13);
            this.lblCustomerName.TabIndex = 7;
            this.lblCustomerName.Text = "Customer Name:";
            // 
            // pbPoppelLogo
            // 
            this.pbPoppelLogo.Image = global::Poppel.Properties.Resources.poppel_logo3;
            this.pbPoppelLogo.Location = new System.Drawing.Point(12, 12);
            this.pbPoppelLogo.Name = "pbPoppelLogo";
            this.pbPoppelLogo.Size = new System.Drawing.Size(108, 83);
            this.pbPoppelLogo.TabIndex = 41;
            this.pbPoppelLogo.TabStop = false;
            // 
            // lblRepID
            // 
            this.lblRepID.AutoSize = true;
            this.lblRepID.Location = new System.Drawing.Point(698, 82);
            this.lblRepID.Name = "lblRepID";
            this.lblRepID.Size = new System.Drawing.Size(45, 13);
            this.lblRepID.TabIndex = 58;
            this.lblRepID.Text = "<R002>";
            // 
            // lblReportID
            // 
            this.lblReportID.AutoSize = true;
            this.lblReportID.Location = new System.Drawing.Point(624, 82);
            this.lblReportID.Name = "lblReportID";
            this.lblReportID.Size = new System.Drawing.Size(56, 13);
            this.lblReportID.TabIndex = 57;
            this.lblReportID.Text = "Report ID:";
            // 
            // OrderConfirmation
            // 
            this.AcceptButton = this.btnConfirmOrder;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Poppel.Properties.Resources.poppel_logo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(798, 607);
            this.Controls.Add(this.lblRepID);
            this.Controls.Add(this.lblReportID);
            this.Controls.Add(this.pbPoppelLogo);
            this.Controls.Add(this.gboCustomerDetails);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnConfirmOrder);
            this.Controls.Add(this.gboDeliveryDetails);
            this.Controls.Add(this.gboItemsOrdered);
            this.Controls.Add(this.lblOrderSummary);
            this.Controls.Add(this.gboOrderDetails);
            this.Name = "OrderConfirmation";
            this.Text = "Order Summary";
            this.gboOrderDetails.ResumeLayout(false);
            this.gboOrderDetails.PerformLayout();
            this.gboItemsOrdered.ResumeLayout(false);
            this.gboDeliveryDetails.ResumeLayout(false);
            this.gboDeliveryDetails.PerformLayout();
            this.gboCustomerDetails.ResumeLayout(false);
            this.gboCustomerDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gboOrderDetails;
        private System.Windows.Forms.Label lblOrderSummary;
        private System.Windows.Forms.Label lblOrdID;
        private System.Windows.Forms.Label lblOrdDate;
        private System.Windows.Forms.Label lblOrderDate;
        private System.Windows.Forms.Label lblOrderID;
        private System.Windows.Forms.GroupBox gboItemsOrdered;
        private System.Windows.Forms.GroupBox gboDeliveryDetails;
        private System.Windows.Forms.Label lblDeliveryAddress;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.Label lblTo;
        private System.Windows.Forms.Label lblStartDate;
        private System.Windows.Forms.Label lblEstimatedDeliveryDates;
        private System.Windows.Forms.Button btnConfirmOrder;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblOrderTotal;
        private System.Windows.Forms.ListView lstItemsOrdered;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.Label lblMarketingClerk;
        private System.Windows.Forms.TextBox txtDeliveryAddress;
        private System.Windows.Forms.GroupBox gboCustomerDetails;
        private System.Windows.Forms.Label lblCustID;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.Label lblCustName;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.PictureBox pbPoppelLogo;
        private System.Windows.Forms.Label lblDeliveryTime;
        private System.Windows.Forms.Label lblRepID;
        private System.Windows.Forms.Label lblReportID;
        private System.Windows.Forms.Label lblOrdTotal;
    }
}