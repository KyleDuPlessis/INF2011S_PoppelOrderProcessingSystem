﻿using System;
using System.Windows.Forms;
using Poppel.Report;
using System.Collections.ObjectModel;
using Poppel.Database;
using Poppel.Order;

namespace Poppel.PresentationLayer
{
    public partial class PickingList : Form
    {
        public PickingListReport pickingListReport;
        private Collection<ReportItem> productList;
        private DateTime pickingDate = DateTime.Now;
        //private OrderController orderController;

        #region Constructor
        public PickingList()
        {
            InitializeComponent();
            lstPickingList.View = View.Details;
            pickingListReport = new PickingListReport();
            productList = new Collection<ReportItem>();

            //lblEmployeeID.Text = orderController.Order.Employee.ID;
        }
        #endregion

        #region Form Events
        private void FillForm()
        {
            lblDate.Visible = true;
            ListViewItem itemInfo;
            
            lstPickingList.Columns.Insert(0, "Item Rack Number", 100, HorizontalAlignment.Left);
            lstPickingList.Columns.Insert(1, "Product ID", 100, HorizontalAlignment.Left);
            lstPickingList.Columns.Insert(2, "Product Name", 150, HorizontalAlignment.Left);
            lstPickingList.Columns.Insert(3, "Product Quantity", 100, HorizontalAlignment.Left);
            lstPickingList.Columns.Insert(4, "Order ID", 100, HorizontalAlignment.Left);
            try
            {
                lblErrorPickingList.Visible = false;
                foreach (ReportItem item in productList)
                {
                    itemInfo = new ListViewItem();
                    itemInfo.Text = item.RackNumber;
                    itemInfo.SubItems.Add(item.ProductID + "");
                    itemInfo.SubItems.Add(item.Description);
                    itemInfo.SubItems.Add(item.Quantity);
                    itemInfo.SubItems.Add(item.OrderID);
                    lstPickingList.Items.Add(itemInfo);
                }
                lstPickingList.Refresh();
                lstPickingList.GridLines = true;
            }
            catch (Exception e)
            {
                lblErrorPickingList.Text = "There are no products available to pick on this date.";
                lblErrorPickingList.Visible = true;
            }
        }
        #endregion

        #region Calender
        private void clnPickDate_Click(object sender, DateRangeEventArgs e)
        {
            pickingDate = clnPickingListDate.SelectionRange.Start;
            lblDate.Text = pickingDate.Day + "-" + pickingDate.Month + "-" + pickingDate.Year;
            productList = pickingListReport.GetOrderProducts(pickingDate);
            clnPickingListDate.Visible = false;
            lstPickingList.Visible = true;
            FillForm();
        }
        #endregion

        #region Buttons
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            PickingList pickingList = new PickingList();
            pickingList.MdiParent = this.MdiParent;
            pickingList.StartPosition = FormStartPosition.CenterScreen;
            pickingList.Show();
            this.Close();
        }
        #endregion
    }
}