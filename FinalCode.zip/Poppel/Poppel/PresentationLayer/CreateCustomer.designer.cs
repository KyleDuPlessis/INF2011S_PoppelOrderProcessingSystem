﻿namespace Poppel.PresentationLayer
{
    partial class CreateCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCreateACustomer = new System.Windows.Forms.Label();
            this.gboDeliveryAddress = new System.Windows.Forms.GroupBox();
            this.lblErrorTown = new System.Windows.Forms.Label();
            this.txtTown = new System.Windows.Forms.TextBox();
            this.lblTown = new System.Windows.Forms.Label();
            this.lblErrorCity = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.lblErrorPostalCode = new System.Windows.Forms.Label();
            this.lblErrorProvince = new System.Windows.Forms.Label();
            this.lblErrorSuburb = new System.Windows.Forms.Label();
            this.lblErrorStreet = new System.Windows.Forms.Label();
            this.lblPostalCode = new System.Windows.Forms.Label();
            this.txtProvince = new System.Windows.Forms.TextBox();
            this.lblProvince = new System.Windows.Forms.Label();
            this.txtSuburb = new System.Windows.Forms.TextBox();
            this.lblSuburb = new System.Windows.Forms.Label();
            this.lblStreet = new System.Windows.Forms.Label();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.gboPersonalDetails = new System.Windows.Forms.GroupBox();
            this.txtEmailAddress = new System.Windows.Forms.TextBox();
            this.txtPhoneNumber = new System.Windows.Forms.MaskedTextBox();
            this.lblErrorEmailAddress = new System.Windows.Forms.Label();
            this.lblErrorPhoneNumber = new System.Windows.Forms.Label();
            this.lblErrorLastName = new System.Windows.Forms.Label();
            this.lblErrorFirstName = new System.Windows.Forms.Label();
            this.lblEmailAddress = new System.Windows.Forms.Label();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.btnCreateCustomer = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblTotalCreditLimit = new System.Windows.Forms.Label();
            this.lblErrorCreateCustomer = new System.Windows.Forms.Label();
            this.gboCustomerCredit = new System.Windows.Forms.GroupBox();
            this.lblErrorTotalCreditLimit = new System.Windows.Forms.Label();
            this.chbModifyTotalCreditLimit = new System.Windows.Forms.CheckBox();
            this.txtTotalCreditLimit = new System.Windows.Forms.TextBox();
            this.pbPoppelLogo = new System.Windows.Forms.PictureBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.gboDeliveryAddress.SuspendLayout();
            this.gboPersonalDetails.SuspendLayout();
            this.gboCustomerCredit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblCreateACustomer
            // 
            this.lblCreateACustomer.AutoSize = true;
            this.lblCreateACustomer.Font = new System.Drawing.Font("Poor Richard", 22F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCreateACustomer.ForeColor = System.Drawing.Color.Orchid;
            this.lblCreateACustomer.Location = new System.Drawing.Point(229, 33);
            this.lblCreateACustomer.Name = "lblCreateACustomer";
            this.lblCreateACustomer.Size = new System.Drawing.Size(243, 35);
            this.lblCreateACustomer.TabIndex = 0;
            this.lblCreateACustomer.Text = "Create a Customer";
            // 
            // gboDeliveryAddress
            // 
            this.gboDeliveryAddress.Controls.Add(this.lblErrorTown);
            this.gboDeliveryAddress.Controls.Add(this.txtTown);
            this.gboDeliveryAddress.Controls.Add(this.lblTown);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorCity);
            this.gboDeliveryAddress.Controls.Add(this.txtCity);
            this.gboDeliveryAddress.Controls.Add(this.lblCity);
            this.gboDeliveryAddress.Controls.Add(this.txtPostalCode);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorPostalCode);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorProvince);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorSuburb);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorStreet);
            this.gboDeliveryAddress.Controls.Add(this.lblPostalCode);
            this.gboDeliveryAddress.Controls.Add(this.txtProvince);
            this.gboDeliveryAddress.Controls.Add(this.lblProvince);
            this.gboDeliveryAddress.Controls.Add(this.txtSuburb);
            this.gboDeliveryAddress.Controls.Add(this.lblSuburb);
            this.gboDeliveryAddress.Controls.Add(this.lblStreet);
            this.gboDeliveryAddress.Controls.Add(this.txtStreet);
            this.gboDeliveryAddress.Location = new System.Drawing.Point(12, 274);
            this.gboDeliveryAddress.Name = "gboDeliveryAddress";
            this.gboDeliveryAddress.Size = new System.Drawing.Size(674, 183);
            this.gboDeliveryAddress.TabIndex = 2;
            this.gboDeliveryAddress.TabStop = false;
            this.gboDeliveryAddress.Text = "Delivery Address";
            // 
            // lblErrorTown
            // 
            this.lblErrorTown.AutoSize = true;
            this.lblErrorTown.ForeColor = System.Drawing.Color.Red;
            this.lblErrorTown.Location = new System.Drawing.Point(467, 57);
            this.lblErrorTown.Name = "lblErrorTown";
            this.lblErrorTown.Size = new System.Drawing.Size(70, 13);
            this.lblErrorTown.TabIndex = 44;
            this.lblErrorTown.Text = "<Error Label>";
            this.lblErrorTown.Visible = false;
            // 
            // txtTown
            // 
            this.txtTown.Location = new System.Drawing.Point(94, 54);
            this.txtTown.Name = "txtTown";
            this.txtTown.Size = new System.Drawing.Size(367, 20);
            this.txtTown.TabIndex = 43;
            // 
            // lblTown
            // 
            this.lblTown.AutoSize = true;
            this.lblTown.Location = new System.Drawing.Point(50, 57);
            this.lblTown.Name = "lblTown";
            this.lblTown.Size = new System.Drawing.Size(37, 13);
            this.lblTown.TabIndex = 42;
            this.lblTown.Text = "Town:";
            // 
            // lblErrorCity
            // 
            this.lblErrorCity.AutoSize = true;
            this.lblErrorCity.ForeColor = System.Drawing.Color.Red;
            this.lblErrorCity.Location = new System.Drawing.Point(467, 108);
            this.lblErrorCity.Name = "lblErrorCity";
            this.lblErrorCity.Size = new System.Drawing.Size(70, 13);
            this.lblErrorCity.TabIndex = 41;
            this.lblErrorCity.Text = "<Error Label>";
            this.lblErrorCity.Visible = false;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(94, 105);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(367, 20);
            this.txtCity.TabIndex = 9;
            this.txtCity.Leave += new System.EventHandler(this.txtTown_Error);
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(60, 108);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(27, 13);
            this.lblCity.TabIndex = 8;
            this.lblCity.Text = "City:";
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(93, 157);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.Size = new System.Drawing.Size(111, 20);
            this.txtPostalCode.TabIndex = 13;
            this.txtPostalCode.Leave += new System.EventHandler(this.txtPostalCode_Error);
            // 
            // lblErrorPostalCode
            // 
            this.lblErrorPostalCode.AutoSize = true;
            this.lblErrorPostalCode.ForeColor = System.Drawing.Color.Red;
            this.lblErrorPostalCode.Location = new System.Drawing.Point(210, 160);
            this.lblErrorPostalCode.Name = "lblErrorPostalCode";
            this.lblErrorPostalCode.Size = new System.Drawing.Size(70, 13);
            this.lblErrorPostalCode.TabIndex = 35;
            this.lblErrorPostalCode.Text = "<Error Label>";
            this.lblErrorPostalCode.Visible = false;
            // 
            // lblErrorProvince
            // 
            this.lblErrorProvince.AutoSize = true;
            this.lblErrorProvince.ForeColor = System.Drawing.Color.Red;
            this.lblErrorProvince.Location = new System.Drawing.Point(467, 134);
            this.lblErrorProvince.Name = "lblErrorProvince";
            this.lblErrorProvince.Size = new System.Drawing.Size(70, 13);
            this.lblErrorProvince.TabIndex = 34;
            this.lblErrorProvince.Text = "<Error Label>";
            this.lblErrorProvince.Visible = false;
            // 
            // lblErrorSuburb
            // 
            this.lblErrorSuburb.AutoSize = true;
            this.lblErrorSuburb.ForeColor = System.Drawing.Color.Red;
            this.lblErrorSuburb.Location = new System.Drawing.Point(467, 83);
            this.lblErrorSuburb.Name = "lblErrorSuburb";
            this.lblErrorSuburb.Size = new System.Drawing.Size(70, 13);
            this.lblErrorSuburb.TabIndex = 33;
            this.lblErrorSuburb.Text = "<Error Label>";
            this.lblErrorSuburb.Visible = false;
            // 
            // lblErrorStreet
            // 
            this.lblErrorStreet.AutoSize = true;
            this.lblErrorStreet.ForeColor = System.Drawing.Color.Red;
            this.lblErrorStreet.Location = new System.Drawing.Point(467, 31);
            this.lblErrorStreet.Name = "lblErrorStreet";
            this.lblErrorStreet.Size = new System.Drawing.Size(70, 13);
            this.lblErrorStreet.TabIndex = 28;
            this.lblErrorStreet.Text = "<Error Label>";
            this.lblErrorStreet.Visible = false;
            // 
            // lblPostalCode
            // 
            this.lblPostalCode.AutoSize = true;
            this.lblPostalCode.Location = new System.Drawing.Point(21, 160);
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.Size = new System.Drawing.Size(67, 13);
            this.lblPostalCode.TabIndex = 12;
            this.lblPostalCode.Text = "Postal Code:";
            this.lblPostalCode.UseWaitCursor = true;
            // 
            // txtProvince
            // 
            this.txtProvince.Location = new System.Drawing.Point(94, 131);
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.Size = new System.Drawing.Size(367, 20);
            this.txtProvince.TabIndex = 11;
            this.txtProvince.TextChanged += new System.EventHandler(this.txtProvince_Error);
            this.txtProvince.Leave += new System.EventHandler(this.txtCity_Error);
            // 
            // lblProvince
            // 
            this.lblProvince.AutoSize = true;
            this.lblProvince.Location = new System.Drawing.Point(35, 134);
            this.lblProvince.Name = "lblProvince";
            this.lblProvince.Size = new System.Drawing.Size(52, 13);
            this.lblProvince.TabIndex = 10;
            this.lblProvince.Text = "Province:";
            // 
            // txtSuburb
            // 
            this.txtSuburb.Location = new System.Drawing.Point(94, 80);
            this.txtSuburb.Name = "txtSuburb";
            this.txtSuburb.Size = new System.Drawing.Size(367, 20);
            this.txtSuburb.TabIndex = 7;
            this.txtSuburb.Leave += new System.EventHandler(this.txtSuburb_Error);
            // 
            // lblSuburb
            // 
            this.lblSuburb.AutoSize = true;
            this.lblSuburb.Location = new System.Drawing.Point(44, 83);
            this.lblSuburb.Name = "lblSuburb";
            this.lblSuburb.Size = new System.Drawing.Size(44, 13);
            this.lblSuburb.TabIndex = 6;
            this.lblSuburb.Text = "Suburb:";
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Location = new System.Drawing.Point(49, 31);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(38, 13);
            this.lblStreet.TabIndex = 4;
            this.lblStreet.Text = "Street:";
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(94, 28);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(367, 20);
            this.txtStreet.TabIndex = 5;
            this.txtStreet.Leave += new System.EventHandler(this.txtStreet_Error);
            // 
            // gboPersonalDetails
            // 
            this.gboPersonalDetails.Controls.Add(this.txtEmailAddress);
            this.gboPersonalDetails.Controls.Add(this.txtPhoneNumber);
            this.gboPersonalDetails.Controls.Add(this.lblErrorEmailAddress);
            this.gboPersonalDetails.Controls.Add(this.lblErrorPhoneNumber);
            this.gboPersonalDetails.Controls.Add(this.lblErrorLastName);
            this.gboPersonalDetails.Controls.Add(this.lblErrorFirstName);
            this.gboPersonalDetails.Controls.Add(this.lblEmailAddress);
            this.gboPersonalDetails.Controls.Add(this.lblPhoneNumber);
            this.gboPersonalDetails.Controls.Add(this.txtLastName);
            this.gboPersonalDetails.Controls.Add(this.lblLastName);
            this.gboPersonalDetails.Controls.Add(this.txtFirstName);
            this.gboPersonalDetails.Controls.Add(this.lblFirstName);
            this.gboPersonalDetails.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gboPersonalDetails.Location = new System.Drawing.Point(12, 139);
            this.gboPersonalDetails.Name = "gboPersonalDetails";
            this.gboPersonalDetails.Size = new System.Drawing.Size(674, 129);
            this.gboPersonalDetails.TabIndex = 1;
            this.gboPersonalDetails.TabStop = false;
            this.gboPersonalDetails.Text = "Personal Details";
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.Location = new System.Drawing.Point(93, 103);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.Size = new System.Drawing.Size(367, 20);
            this.txtEmailAddress.TabIndex = 7;
            this.txtEmailAddress.Leave += new System.EventHandler(this.txtEmailAddress_Error);
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(93, 77);
            this.txtPhoneNumber.Mask = "(000) 000-0000";
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.Size = new System.Drawing.Size(367, 20);
            this.txtPhoneNumber.TabIndex = 5;
            this.txtPhoneNumber.Leave += new System.EventHandler(this.txtPhoneNumber_Error);
            // 
            // lblErrorEmailAddress
            // 
            this.lblErrorEmailAddress.AutoSize = true;
            this.lblErrorEmailAddress.ForeColor = System.Drawing.Color.Red;
            this.lblErrorEmailAddress.Location = new System.Drawing.Point(466, 106);
            this.lblErrorEmailAddress.Name = "lblErrorEmailAddress";
            this.lblErrorEmailAddress.Size = new System.Drawing.Size(70, 13);
            this.lblErrorEmailAddress.TabIndex = 27;
            this.lblErrorEmailAddress.Text = "<Error Label>";
            this.lblErrorEmailAddress.Visible = false;
            // 
            // lblErrorPhoneNumber
            // 
            this.lblErrorPhoneNumber.AutoSize = true;
            this.lblErrorPhoneNumber.ForeColor = System.Drawing.Color.Red;
            this.lblErrorPhoneNumber.Location = new System.Drawing.Point(466, 80);
            this.lblErrorPhoneNumber.Name = "lblErrorPhoneNumber";
            this.lblErrorPhoneNumber.Size = new System.Drawing.Size(70, 13);
            this.lblErrorPhoneNumber.TabIndex = 26;
            this.lblErrorPhoneNumber.Text = "<Error Label>";
            this.lblErrorPhoneNumber.Visible = false;
            // 
            // lblErrorLastName
            // 
            this.lblErrorLastName.AutoSize = true;
            this.lblErrorLastName.ForeColor = System.Drawing.Color.Red;
            this.lblErrorLastName.Location = new System.Drawing.Point(466, 54);
            this.lblErrorLastName.Name = "lblErrorLastName";
            this.lblErrorLastName.Size = new System.Drawing.Size(70, 13);
            this.lblErrorLastName.TabIndex = 25;
            this.lblErrorLastName.Text = "<Error Label>";
            this.lblErrorLastName.Visible = false;
            // 
            // lblErrorFirstName
            // 
            this.lblErrorFirstName.AutoSize = true;
            this.lblErrorFirstName.ForeColor = System.Drawing.Color.Red;
            this.lblErrorFirstName.Location = new System.Drawing.Point(466, 28);
            this.lblErrorFirstName.Name = "lblErrorFirstName";
            this.lblErrorFirstName.Size = new System.Drawing.Size(70, 13);
            this.lblErrorFirstName.TabIndex = 24;
            this.lblErrorFirstName.Text = "<Error Label>";
            this.lblErrorFirstName.Visible = false;
            // 
            // lblEmailAddress
            // 
            this.lblEmailAddress.AutoSize = true;
            this.lblEmailAddress.Location = new System.Drawing.Point(11, 106);
            this.lblEmailAddress.Name = "lblEmailAddress";
            this.lblEmailAddress.Size = new System.Drawing.Size(76, 13);
            this.lblEmailAddress.TabIndex = 6;
            this.lblEmailAddress.Text = "Email Address:";
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(6, 80);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(81, 13);
            this.lblPhoneNumber.TabIndex = 4;
            this.lblPhoneNumber.Text = "Phone Number:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(93, 51);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(367, 20);
            this.txtLastName.TabIndex = 3;
            this.txtLastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtLastName_KeyPress);
            this.txtLastName.Leave += new System.EventHandler(this.txtLastName_Error);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(27, 54);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(93, 25);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(367, 20);
            this.txtFirstName.TabIndex = 1;
            this.txtFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtFirstName_KeyPress);
            this.txtFirstName.Leave += new System.EventHandler(this.txtFirstName_Error);
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(27, 28);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            // 
            // btnCreateCustomer
            // 
            this.btnCreateCustomer.Location = new System.Drawing.Point(366, 561);
            this.btnCreateCustomer.Name = "btnCreateCustomer";
            this.btnCreateCustomer.Size = new System.Drawing.Size(106, 40);
            this.btnCreateCustomer.TabIndex = 5;
            this.btnCreateCustomer.Text = "Create Customer";
            this.btnCreateCustomer.UseVisualStyleBackColor = true;
            this.btnCreateCustomer.Click += new System.EventHandler(this.btnCreateCustomer_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(190, 561);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(81, 40);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblTotalCreditLimit
            // 
            this.lblTotalCreditLimit.AutoSize = true;
            this.lblTotalCreditLimit.Location = new System.Drawing.Point(6, 42);
            this.lblTotalCreditLimit.Name = "lblTotalCreditLimit";
            this.lblTotalCreditLimit.Size = new System.Drawing.Size(88, 13);
            this.lblTotalCreditLimit.TabIndex = 1;
            this.lblTotalCreditLimit.Text = "Total Credit Limit:";
            // 
            // lblErrorCreateCustomer
            // 
            this.lblErrorCreateCustomer.BackColor = System.Drawing.SystemColors.Control;
            this.lblErrorCreateCustomer.ForeColor = System.Drawing.Color.Red;
            this.lblErrorCreateCustomer.Location = new System.Drawing.Point(103, 540);
            this.lblErrorCreateCustomer.Name = "lblErrorCreateCustomer";
            this.lblErrorCreateCustomer.Size = new System.Drawing.Size(476, 18);
            this.lblErrorCreateCustomer.TabIndex = 28;
            this.lblErrorCreateCustomer.Text = "<Error Label>";
            this.lblErrorCreateCustomer.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblErrorCreateCustomer.Visible = false;
            // 
            // gboCustomerCredit
            // 
            this.gboCustomerCredit.Controls.Add(this.lblErrorTotalCreditLimit);
            this.gboCustomerCredit.Controls.Add(this.chbModifyTotalCreditLimit);
            this.gboCustomerCredit.Controls.Add(this.lblTotalCreditLimit);
            this.gboCustomerCredit.Controls.Add(this.txtTotalCreditLimit);
            this.gboCustomerCredit.Location = new System.Drawing.Point(12, 463);
            this.gboCustomerCredit.Name = "gboCustomerCredit";
            this.gboCustomerCredit.Size = new System.Drawing.Size(674, 74);
            this.gboCustomerCredit.TabIndex = 3;
            this.gboCustomerCredit.TabStop = false;
            this.gboCustomerCredit.Text = "Customer Credit";
            // 
            // lblErrorTotalCreditLimit
            // 
            this.lblErrorTotalCreditLimit.AutoSize = true;
            this.lblErrorTotalCreditLimit.ForeColor = System.Drawing.Color.Red;
            this.lblErrorTotalCreditLimit.Location = new System.Drawing.Point(216, 42);
            this.lblErrorTotalCreditLimit.Name = "lblErrorTotalCreditLimit";
            this.lblErrorTotalCreditLimit.Size = new System.Drawing.Size(70, 13);
            this.lblErrorTotalCreditLimit.TabIndex = 30;
            this.lblErrorTotalCreditLimit.Text = "<Error Label>";
            this.lblErrorTotalCreditLimit.Visible = false;
            // 
            // chbModifyTotalCreditLimit
            // 
            this.chbModifyTotalCreditLimit.AutoSize = true;
            this.chbModifyTotalCreditLimit.Location = new System.Drawing.Point(100, 16);
            this.chbModifyTotalCreditLimit.Name = "chbModifyTotalCreditLimit";
            this.chbModifyTotalCreditLimit.Size = new System.Drawing.Size(138, 17);
            this.chbModifyTotalCreditLimit.TabIndex = 0;
            this.chbModifyTotalCreditLimit.Text = "Modify Total Credit Limit";
            this.chbModifyTotalCreditLimit.UseVisualStyleBackColor = true;
            this.chbModifyTotalCreditLimit.CheckedChanged += new System.EventHandler(this.chbModifyCreditLimit_CheckedChanged);
            // 
            // txtTotalCreditLimit
            // 
            this.txtTotalCreditLimit.Location = new System.Drawing.Point(100, 39);
            this.txtTotalCreditLimit.Name = "txtTotalCreditLimit";
            this.txtTotalCreditLimit.ReadOnly = true;
            this.txtTotalCreditLimit.Size = new System.Drawing.Size(110, 20);
            this.txtTotalCreditLimit.TabIndex = 2;
            this.txtTotalCreditLimit.Text = "2000";
            this.txtTotalCreditLimit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCreditLimit_KeyPress);
            this.txtTotalCreditLimit.Leave += new System.EventHandler(this.txtCreditLimit_Error);
            // 
            // pbPoppelLogo
            // 
            this.pbPoppelLogo.Image = global::Poppel.Properties.Resources.poppel_logo3;
            this.pbPoppelLogo.Location = new System.Drawing.Point(12, 12);
            this.pbPoppelLogo.Name = "pbPoppelLogo";
            this.pbPoppelLogo.Size = new System.Drawing.Size(111, 96);
            this.pbPoppelLogo.TabIndex = 37;
            this.pbPoppelLogo.TabStop = false;
            // 
            // btnClear
            // 
            this.btnClear.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnClear.Location = new System.Drawing.Point(277, 561);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(81, 40);
            this.btnClear.TabIndex = 38;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // CreateCustomer
            // 
            this.AcceptButton = this.btnCreateCustomer;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Poppel.Properties.Resources.poppel_logo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(715, 623);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.pbPoppelLogo);
            this.Controls.Add(this.gboCustomerCredit);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lblErrorCreateCustomer);
            this.Controls.Add(this.btnCreateCustomer);
            this.Controls.Add(this.gboPersonalDetails);
            this.Controls.Add(this.gboDeliveryAddress);
            this.Controls.Add(this.lblCreateACustomer);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "CreateCustomer";
            this.Text = "CreateCustomer";
            this.gboDeliveryAddress.ResumeLayout(false);
            this.gboDeliveryAddress.PerformLayout();
            this.gboPersonalDetails.ResumeLayout(false);
            this.gboPersonalDetails.PerformLayout();
            this.gboCustomerCredit.ResumeLayout(false);
            this.gboCustomerCredit.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCreateACustomer;
        private System.Windows.Forms.GroupBox gboDeliveryAddress;
        private System.Windows.Forms.Label lblPostalCode;
        private System.Windows.Forms.TextBox txtProvince;
        private System.Windows.Forms.Label lblProvince;
        private System.Windows.Forms.TextBox txtSuburb;
        private System.Windows.Forms.Label lblSuburb;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.GroupBox gboPersonalDetails;
        private System.Windows.Forms.Label lblEmailAddress;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Button btnCreateCustomer;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblErrorLastName;
        private System.Windows.Forms.Label lblErrorFirstName;
        private System.Windows.Forms.Label lblErrorPostalCode;
        private System.Windows.Forms.Label lblErrorProvince;
        private System.Windows.Forms.Label lblErrorSuburb;
        private System.Windows.Forms.Label lblErrorStreet;
        private System.Windows.Forms.Label lblErrorEmailAddress;
        private System.Windows.Forms.Label lblErrorPhoneNumber;
        private System.Windows.Forms.Label lblTotalCreditLimit;
        private System.Windows.Forms.Label lblErrorCreateCustomer;
        private System.Windows.Forms.GroupBox gboCustomerCredit;
        private System.Windows.Forms.TextBox txtTotalCreditLimit;
        private System.Windows.Forms.CheckBox chbModifyTotalCreditLimit;
        private System.Windows.Forms.MaskedTextBox txtPhoneNumber;
        private System.Windows.Forms.TextBox txtEmailAddress;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.Label lblErrorTotalCreditLimit;
        private System.Windows.Forms.Label lblErrorCity;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.PictureBox pbPoppelLogo;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label lblErrorTown;
        private System.Windows.Forms.TextBox txtTown;
        private System.Windows.Forms.Label lblTown;
    }
}