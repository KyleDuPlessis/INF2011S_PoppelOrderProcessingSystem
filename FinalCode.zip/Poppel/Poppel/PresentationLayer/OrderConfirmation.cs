﻿using System;
using System.Windows.Forms;
using Poppel.Order;
using Poppel.Database;


namespace Poppel.PresentationLayer
{
    public partial class OrderConfirmation : Form
    {
        private OrderController orderController;

        #region Constructor
        public OrderConfirmation(Poppel.Order.OrderController orderController)
        {
            InitializeComponent();
            this.orderController = orderController;
            PopulateForm();
        }
        #endregion

        #region Form Events
        private void PopulateForm()
        {
            lblCustName.Text = orderController.Order.Customer.NameToString();
            lblCustID.Text = orderController.Order.Customer.ID;
            lblOrdDate.Text = orderController.Order.DateOrderPlaced.ToShortDateString();
            lblOrdID.Text = orderController.Order.OrderID.ToString();
            lblEmployeeName.Text = orderController.Order.Employee.NameToString();
            lblOrdTotal.Text = "R " + string.Format("{0:0.00}", (orderController.Order.OrderPrice));
            lstItemsOrdered.View = View.Details;
            string addressDetails = orderController.Order.Customer.DeliveryAddressMultilineToString();
            txtDeliveryAddress.Text = addressDetails;
            txtDeliveryAddress.ReadOnly = true;
            lblStartDate.Text = DateTime.Today.AddDays(3).ToShortDateString();
            lblEndDate.Text = DateTime.Today.AddDays(7).ToShortDateString();

            FillItemsOrderedListView();

            foreach (OrderItem item in orderController.Order.Products)
            {
                AddItemToOrder(item);
            }      
        }

        public void FillItemsOrderedListView()
        {
            lstItemsOrdered.Clear();
            lstItemsOrdered.Columns.Insert(0, "Product", 130, HorizontalAlignment.Left);
            lstItemsOrdered.Columns.Insert(1, "Product Quantity", 55, HorizontalAlignment.Left);
            lstItemsOrdered.Columns.Insert(2, "Item Cost", 80, HorizontalAlignment.Left);
            lstItemsOrdered.Columns.Insert(3, "Item Total", 80, HorizontalAlignment.Left);
            lstItemsOrdered.Columns.Insert(4, "", 0, HorizontalAlignment.Left);
            lstItemsOrdered.Refresh();
            lstItemsOrdered.GridLines = true;
        }

        public void AddItemToOrder(OrderItem orderItem)
        {
            ListViewItem orderItemInfo;
            orderItemInfo = new ListViewItem();
            orderItemInfo.Text = "" + orderItem.Product.Description;
            orderItemInfo.SubItems.Add("" + orderItem.Quantity);
            orderItemInfo.SubItems.Add("R " + string.Format("{0:0.00}", (orderItem.Product.Price)));
            orderItemInfo.SubItems.Add("R " + string.Format("{0:0.00}", (orderItem.Quantity * orderItem.Product.Price)));
            
            orderItemInfo.SubItems[0].Tag = orderItem.Product.ID;
            lstItemsOrdered.Items.Add(orderItemInfo);
        }
        #endregion

        #region Buttons
        private void btnConfirmOrder_Click(object sender, EventArgs e)
        {
            orderController.SubmitOrder();
            MessageBox.Show("Your order has been confirmed!");
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to cancel this order?", "Confirm Cancel Order", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        #endregion
    }
}
