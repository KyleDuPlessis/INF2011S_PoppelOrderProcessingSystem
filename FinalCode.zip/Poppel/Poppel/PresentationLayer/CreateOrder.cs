﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Poppel.Order;
using Poppel.Domain;
using Poppel.CustomerMangement;

namespace Poppel.PresentationLayer
{
    public partial class CreateOrder : Form
    {
        private OrderController orderController;
        private Collection<OrderItem> products;

        #region Constructor
        public CreateOrder(OrderController orderController)
        {
            InitializeComponent();
            this.orderController = orderController;
            SetUpForm();
        }
        #endregion

        #region Form Events
        private void SetUpForm()
        {
            products = orderController.GetProducts();
            orderController.DisplayedProducts = new Collection<OrderItemForm>();
            orderController.AllProducts = new Collection<OrderItemForm>();
           
            SetUpEmployeeListView();
            SetUpOrderFlowPanel();
            lstCart.View = View.Details;
            Collection<Category> categories = orderController.GetCategories();
            cboProductCategorySearch.Items.Add("All");
            cboProductCategorySearch.SelectedIndex = 0;
            foreach (Category category in categories)
            {
                cboProductCategorySearch.Items.Add(category);
            }

            txtCreditRemaining.Text = Product.GetFormattedPrice(orderController.CustomerManagementController.Customer.CreditLimit-orderController.CustomerManagementController.Customer.Credit);
        }
        #endregion

        #region Flow Panel
        private void SetUpOrderFlowPanel()
        {
            foreach (OrderItem orderItem in products)
            {

                OrderItemForm orderItemForm = new OrderItemForm(orderItem);
                orderItemForm.OrderQuantityNumericUpDown.ValueChanged += new EventHandler(orderQuantity_ValueChanged);
                orderItemForm.PlaceOrderButton.Click += new EventHandler(this.btnAdd_Click);
                flpStockItems.Controls.Add(orderItemForm.ProductPanel);
                orderController.DisplayedProducts.Add(orderItemForm);
                orderController.AllProducts.Add(orderItemForm);
            }
        }

        private void flowLayoutPanel_MouseEnter(object sender, EventArgs e)
        {
            //   stockItemsFlowLayoutPanel.Focus();
        }

        private void flowLayoutPanel_MouseClick(object sender, MouseEventArgs e)
        {
            flpStockItems.Focus();
        }
        #endregion

        #region ListView
        public void SetUpEmployeeListView()
        {
            //Clear current List View Control
            lstCart.Clear();

            //Set Up Columns of List View
            lstCart.Columns.Insert(0, "Product", 95, HorizontalAlignment.Left);
            lstCart.Columns.Insert(1, "Quantity", 55, HorizontalAlignment.Left);
            lstCart.Columns.Insert(2, "Cost", 75, HorizontalAlignment.Left);
            lstCart.Columns.Insert(3, "", 0, HorizontalAlignment.Left);

            //Add employee details to each ListView item 

            lstCart.Refresh();
            lstCart.GridLines = true;
        }

        private void lstCart_Click(object sender, EventArgs e)
        {
            btnRemoveProductFromOrder.Enabled = true;
        }

        private void lstCart_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (lstCart.SelectedItems.Count == 0)
            {
                btnRemoveProductFromOrder.Enabled = false;
            }
            else
            {
                btnRemoveProductFromOrder.Enabled = true;
            }
        }

        private void lstCart_Leave(object sender, EventArgs e)
        {
            //       removeFromOrderButton.Enabled = false;
        }
        #endregion

        #region Add Item
        public void AddToOrder(OrderItem orderItem)
        {
            ListViewItem orderItemDetails;
            orderItemDetails = new ListViewItem();
            orderItemDetails.Text = "" + orderItem.Product.Description;
            orderItemDetails.SubItems.Add("" + orderItem.Quantity);
            orderItemDetails.SubItems.Add("R " + string.Format("{0:0.00}", (orderItem.Quantity * orderItem.Product.Price)));
            orderItemDetails.SubItems[0].Tag = orderItem.Product.ID;
            lstCart.Items.Add(orderItemDetails);

            orderController.OrderItems.Add(orderItem);
            checkOutButton.Enabled = true;

            orderController.OrderTotal += (orderItem.Quantity * orderItem.Product.Price);
            txtTotalCost.Text = "R " + string.Format("{0:0.00}", (orderController.OrderTotal));
            txtCreditRemaining.Text = Product.GetFormattedPrice(orderController.CustomerManagementController.Customer.CreditLimit - orderController.CustomerManagementController.Customer.Credit - orderController.OrderTotal);          
        }

        public void UpdateVisibleQuantity(OrderItem item)
        {
            OrderItemForm form = OrderController.GetClickedForm(item.Product.ID, orderController.DisplayedProducts);
            form.OrderQuantityNumericUpDown.Value = item.Quantity;
        }

        public void ShowAddedItem(OrderItem orderItem)
        {
            ListViewItem orderItemDetails;
            orderItemDetails = new ListViewItem();
            orderItemDetails.Text = "" + orderItem.Product.Description;
            orderItemDetails.SubItems.Add("" + orderItem.Quantity);
            orderItemDetails.SubItems.Add("R " + string.Format("{0:0.00}", (orderItem.Quantity * orderItem.Product.Price)));
            orderItemDetails.SubItems[0].Tag = orderItem.Product.ID;
            lstCart.Items.Add(orderItemDetails);

            checkOutButton.Enabled = true;

            orderController.OrderTotal += (orderItem.Quantity * orderItem.Product.Price);
            txtTotalCost.Text = "R " + string.Format("{0:0.00}", (orderController.OrderTotal));
            btnAddPressed(orderItem.Product.ID);
        }

        private void orderQuantity_ValueChanged(object sender, EventArgs e)
        {
            NumericUpDown quantityUpDown = (NumericUpDown)sender;
            int id = -1;
            if (int.TryParse(quantityUpDown.Tag.ToString(), out id))
            {
                OrderController.GetProduct(id, products).Quantity = decimal.ToInt32(quantityUpDown.Value);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            int id = -1;
            if (int.TryParse(clickedButton.Tag.ToString(), out id))
            {
                OrderItem orderItem = OrderController.GetProduct(id, products);
                if (orderController.CustomerManagementController.Customer.CreditLimit - orderController.CustomerManagementController.Customer.Credit - orderController.OrderTotal - (orderItem.Quantity * orderItem.Product.Price) >= 0)
                {
                    AddToOrder(orderItem);
                    btnAddPressed(id);
                }
                else
                {
                    string message = "Item could not be added.\nCredit limit would be exceeded.";
                    string caption = "Item cannot be addded";
                    MessageBoxButtons buttons = MessageBoxButtons.OK;
                    DialogResult result;

                    // Displays the MessageBox.

                    result = MessageBox.Show(message, caption, buttons);
                }
            }
        }

        public void btnAddPressed(int id)
        {
            OrderItemForm clickedForm = OrderController.GetClickedForm(id, orderController.DisplayedProducts);
            clickedForm.PlaceOrderButton.Text = "Remove";
            clickedForm.PlaceOrderButton.Click -= btnAdd_Click;
            clickedForm.PlaceOrderButton.Click += btnRemove_Click;
            clickedForm.OrderQuantityNumericUpDown.Enabled = false;
        }
        #endregion

        #region Remove Item
        private void btnRemove_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to remove this item from the order?", "Confirm Removal", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                Button clickedButton = (Button)sender;
                int id = -1;
                if (int.TryParse(clickedButton.Tag.ToString(), out id))
                {
                    btnRemoveClicked(id);
                }
            }
        }

        private void btnRemoveClicked(int id)
        {
            RemoveFromOrder(id);
            OrderItemForm clickedForm = OrderController.GetClickedForm(id, orderController.DisplayedProducts);
            clickedForm.PlaceOrderButton.Text = "Add";
            clickedForm.PlaceOrderButton.Click -= btnRemove_Click;
            clickedForm.PlaceOrderButton.Click += btnAdd_Click;
        }

        private void btnRemoveFromOrder_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to remove this item from the order?", "Confirm Removal", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                int parseInt = -1;
                if (int.TryParse(lstCart.SelectedItems[0].SubItems[0].Tag.ToString(), out parseInt))
                {
                    int index = 0;
                    bool changed = false;
                    while (index < orderController.AllProducts.Count && !changed)
                    {
                        if (orderController.AllProducts[index].RefOrderItem.Product.ID == parseInt)
                        {
                            OrderItemForm form = orderController.AllProducts[index];
                            form.PlaceOrderButton.Text = "Add";
                            form.PlaceOrderButton.Click -= btnRemove_Click;
                            form.PlaceOrderButton.Click += btnAdd_Click;
                        }
                        index++;
                    }
                    RemoveFromOrder(parseInt);
                }
            }
            else if (dialogResult == DialogResult.No)
            {
                //do something else
            }
        }

        private void RemoveFromOrder(int parseInt)
        {
            OrderItem removalItem = OrderController.GetProduct(parseInt, products);
            OrderItemForm removeForm = OrderController.GetClickedForm(parseInt, orderController.DisplayedProducts);
            orderController.OrderItems.Remove(removalItem);
            int index = 0;
            for (int i = 0; i < lstCart.Items.Count; i++)
            {
                if (int.TryParse(lstCart.Items[i].SubItems[0].Tag.ToString(), out index))
                {
                    if (index == parseInt)
                    {
                        lstCart.Items.Remove(lstCart.Items[i]);
                        break;
                    }
                }
            }
            orderController.OrderTotal -= (removalItem.Product.Price * removalItem.Quantity);
            
            txtTotalCost.Text = "R " + string.Format("{0:0.00}", (orderController.OrderTotal));
            txtCreditRemaining.Text = Product.GetFormattedPrice(orderController.CustomerManagementController.Customer.CreditLimit - orderController.CustomerManagementController.Customer.Credit - orderController.OrderTotal);

            OrderItemForm clickedForm = OrderController.GetClickedForm(parseInt, orderController.DisplayedProducts);
            clickedForm.PlaceOrderButton.Enabled = true;
            if (orderController.OrderItems.Count == 0)
            {
                checkOutButton.Enabled = false;
            }
            removeForm.OrderQuantityNumericUpDown.Enabled = true;
        }
        #endregion

        #region Search
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            flpStockItems.Controls.Clear();
            foreach (OrderItemForm orderItemForm in orderController.DisplayedProducts)
            {
                if (orderItemForm.ProductDescriptionLabel.Text.ToLower().Contains(txtProductNameSearch.Text.ToLower()))
                {
                    flpStockItems.Controls.Add(orderItemForm.ProductPanel);
                }
            }
        }

        private void cboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            orderController.SetCategory(cboProductCategorySearch.Text);
            flpStockItems.Controls.Clear();
            foreach (OrderItemForm orderItemForm in orderController.DisplayedProducts)
            {
                flpStockItems.Controls.Add(orderItemForm.ProductPanel);
            }
        }

        private void btnRemoveFilters_Click(object sender, EventArgs e)
        {
            txtProductNameSearch.Text = "";
            cboProductCategorySearch.SelectedIndex = 0;
            flpStockItems.Controls.Clear();
            foreach (OrderItemForm orderItemForm in orderController.DisplayedProducts)
            {
                flpStockItems.Controls.Add(orderItemForm.ProductPanel);
            }
        }
        #endregion

        #region Buttons
        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            orderController.Checkout();
            OrderConfirmation orderSummary = new OrderConfirmation(orderController);
            orderSummary.MdiParent = this.MdiParent;
            orderSummary.StartPosition = FormStartPosition.CenterScreen;
            this.Close();
            orderSummary.Show();
        }

        private void btnCancelOrder_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you sure you want to cancel this order?", "Confirm Cancel Order", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            CustomerManagement customerManagement = new CustomerManagement(orderController.CustomerManagementController);
            customerManagement.Search(orderController.CustomerManagementController.Customer.ID);
            customerManagement.MdiParent = this.MdiParent;
            customerManagement.StartPosition = FormStartPosition.CenterScreen;
            this.Close();
            customerManagement.Show();
        }
        #endregion

        private void buttonCancel_Click(object sender, EventArgs e)
        {

            DialogResult dialogResult = MessageBox.Show("Are you sure you want to cancel this order?", "Confirm Cancel Order", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {

            CustomerManagement customerManagement = new CustomerManagement(orderController.CustomerManagementController);
            customerManagement.Search(orderController.CustomerManagementController.Customer.ID);
            customerManagement.MdiParent = this.MdiParent;
            customerManagement.StartPosition = FormStartPosition.CenterScreen;
            this.Close();
            customerManagement.Show();

        }

        private void buttonCheckout_Click(object sender, EventArgs e)
        {
            orderController.Checkout();
            OrderConfirmation orderSummary = new OrderConfirmation(orderController);
            orderSummary.MdiParent = this.MdiParent;
            orderSummary.StartPosition = FormStartPosition.CenterScreen;
            this.Close();
            orderSummary.Show();
        }
    }
}
