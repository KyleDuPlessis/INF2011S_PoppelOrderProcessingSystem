﻿namespace Poppel.Report
{
    partial class ExpiredProducts
    {

        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.lstProducts = new System.Windows.Forms.ListView();
            this.lblExpiredProducts = new System.Windows.Forms.Label();
            this.pickDateCalendar = new System.Windows.Forms.MonthCalendar();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblGeneratedOn = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.lblReportID = new System.Windows.Forms.Label();
            this.lblRepID = new System.Windows.Forms.Label();
            this.pbPoppelLogo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(580, 490);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(81, 40);
            this.btnCancel.TabIndex = 46;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lstProducts
            // 
            this.lstProducts.HoverSelection = true;
            this.lstProducts.Location = new System.Drawing.Point(29, 173);
            this.lstProducts.Margin = new System.Windows.Forms.Padding(2);
            this.lstProducts.Name = "lstProducts";
            this.lstProducts.Size = new System.Drawing.Size(719, 312);
            this.lstProducts.TabIndex = 45;
            this.lstProducts.UseCompatibleStateImageBehavior = false;
            this.lstProducts.Visible = false;
            // 
            // lblExpiredProducts
            // 
            this.lblExpiredProducts.AutoSize = true;
            this.lblExpiredProducts.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblExpiredProducts.Font = new System.Drawing.Font("Poor Richard", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExpiredProducts.ForeColor = System.Drawing.Color.Orchid;
            this.lblExpiredProducts.Location = new System.Drawing.Point(225, 12);
            this.lblExpiredProducts.Name = "lblExpiredProducts";
            this.lblExpiredProducts.Size = new System.Drawing.Size(386, 33);
            this.lblExpiredProducts.TabIndex = 38;
            this.lblExpiredProducts.Text = "Expired Products Inventory List";
            // 
            // pickDateCalendar
            // 
            this.pickDateCalendar.Location = new System.Drawing.Point(285, 206);
            this.pickDateCalendar.Margin = new System.Windows.Forms.Padding(7);
            this.pickDateCalendar.Name = "pickDateCalendar";
            this.pickDateCalendar.TabIndex = 47;
            this.pickDateCalendar.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.clnPickDate_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(667, 490);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(81, 40);
            this.btnReset.TabIndex = 48;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblGeneratedOn
            // 
            this.lblGeneratedOn.AutoSize = true;
            this.lblGeneratedOn.Location = new System.Drawing.Point(73, 143);
            this.lblGeneratedOn.Name = "lblGeneratedOn";
            this.lblGeneratedOn.Size = new System.Drawing.Size(77, 13);
            this.lblGeneratedOn.TabIndex = 52;
            this.lblGeneratedOn.Text = "Generated On:";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(171, 143);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(42, 13);
            this.lblDate.TabIndex = 54;
            this.lblDate.Text = "<Date>";
            // 
            // lblReportID
            // 
            this.lblReportID.AutoSize = true;
            this.lblReportID.Location = new System.Drawing.Point(555, 112);
            this.lblReportID.Name = "lblReportID";
            this.lblReportID.Size = new System.Drawing.Size(56, 13);
            this.lblReportID.TabIndex = 55;
            this.lblReportID.Text = "Report ID:";
            // 
            // lblRepID
            // 
            this.lblRepID.AutoSize = true;
            this.lblRepID.Location = new System.Drawing.Point(629, 112);
            this.lblRepID.Name = "lblRepID";
            this.lblRepID.Size = new System.Drawing.Size(45, 13);
            this.lblRepID.TabIndex = 56;
            this.lblRepID.Text = "<R001>";
            // 
            // pbPoppelLogo
            // 
            this.pbPoppelLogo.Image = global::Poppel.Properties.Resources.poppel_logo3;
            this.pbPoppelLogo.Location = new System.Drawing.Point(12, 12);
            this.pbPoppelLogo.Name = "pbPoppelLogo";
            this.pbPoppelLogo.Size = new System.Drawing.Size(108, 83);
            this.pbPoppelLogo.TabIndex = 50;
            this.pbPoppelLogo.TabStop = false;
            // 
            // ExpiredProducts
            // 
            this.BackgroundImage = global::Poppel.Properties.Resources.poppel_logo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(772, 542);
            this.Controls.Add(this.lblRepID);
            this.Controls.Add(this.lblReportID);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblGeneratedOn);
            this.Controls.Add(this.pbPoppelLogo);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.pickDateCalendar);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lstProducts);
            this.Controls.Add(this.lblExpiredProducts);
            this.Name = "ExpiredProducts";
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.ListView lstProducts;
        private System.Windows.Forms.Label lblExpiredProducts;
        private System.Windows.Forms.MonthCalendar pickDateCalendar;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.PictureBox pbPoppelLogo;
        private System.Windows.Forms.Label lblGeneratedOn;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Label lblReportID;
        private System.Windows.Forms.Label lblRepID;
    }
}