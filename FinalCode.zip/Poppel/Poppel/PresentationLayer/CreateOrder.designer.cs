﻿namespace Poppel.PresentationLayer
{
    partial class CreateOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.flpStockItems = new System.Windows.Forms.FlowLayoutPanel();
            this.lblFilterAvailableProducts = new System.Windows.Forms.Label();
            this.headerLabel = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.txtProductNameSearch = new System.Windows.Forms.TextBox();
            this.lblCart = new System.Windows.Forms.Label();
            this.lstCart = new System.Windows.Forms.ListView();
            this.lblProductCategory = new System.Windows.Forms.Label();
            this.checkOutButton = new System.Windows.Forms.Button();
            this.cboProductCategorySearch = new System.Windows.Forms.ComboBox();
            this.btnRemoveProductFromOrder = new System.Windows.Forms.Button();
            this.btnClearFilters = new System.Windows.Forms.Button();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.lblCreditRemaining = new System.Windows.Forms.Label();
            this.txtTotalCost = new System.Windows.Forms.TextBox();
            this.txtCreditRemaining = new System.Windows.Forms.TextBox();
            this.poppelDatabaseDataSet1 = new Poppel.PoppelDatabaseDataSet();
            this.cancelOrderButton = new System.Windows.Forms.Button();
            this.backButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.poppelDatabaseDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // flpStockItems
            // 
            this.flpStockItems.AutoScroll = true;
            this.flpStockItems.Location = new System.Drawing.Point(12, 120);
            this.flpStockItems.Name = "flpStockItems";
            this.flpStockItems.Size = new System.Drawing.Size(654, 708);
            this.flpStockItems.TabIndex = 0;
            this.flpStockItems.MouseClick += new System.Windows.Forms.MouseEventHandler(this.flowLayoutPanel_MouseClick);
            this.flpStockItems.MouseEnter += new System.EventHandler(this.flowLayoutPanel_MouseEnter);
            // 
            // lblFilterAvailableProducts
            // 
            this.lblFilterAvailableProducts.AutoSize = true;
            this.lblFilterAvailableProducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilterAvailableProducts.Location = new System.Drawing.Point(759, 157);
            this.lblFilterAvailableProducts.Name = "lblFilterAvailableProducts";
            this.lblFilterAvailableProducts.Size = new System.Drawing.Size(191, 20);
            this.lblFilterAvailableProducts.TabIndex = 1;
            this.lblFilterAvailableProducts.Text = "Filter Available Products";
            // 
            // headerLabel
            // 
            this.headerLabel.AutoSize = true;
            this.headerLabel.Font = new System.Drawing.Font("Poor Richard", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headerLabel.ForeColor = System.Drawing.Color.Orchid;
            this.headerLabel.Location = new System.Drawing.Point(340, 39);
            this.headerLabel.Name = "headerLabel";
            this.headerLabel.Size = new System.Drawing.Size(210, 33);
            this.headerLabel.TabIndex = 17;
            this.headerLabel.Text = "Create an Order";
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Location = new System.Drawing.Point(704, 193);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(76, 13);
            this.lblProductName.TabIndex = 0;
            this.lblProductName.Text = "Product name:";
            // 
            // txtProductNameSearch
            // 
            this.txtProductNameSearch.Location = new System.Drawing.Point(801, 190);
            this.txtProductNameSearch.Name = "txtProductNameSearch";
            this.txtProductNameSearch.Size = new System.Drawing.Size(149, 20);
            this.txtProductNameSearch.TabIndex = 18;
            this.txtProductNameSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // lblCart
            // 
            this.lblCart.AutoSize = true;
            this.lblCart.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCart.Location = new System.Drawing.Point(793, 284);
            this.lblCart.Name = "lblCart";
            this.lblCart.Size = new System.Drawing.Size(41, 20);
            this.lblCart.TabIndex = 19;
            this.lblCart.Text = "Cart";
            // 
            // lstCart
            // 
            this.lstCart.Location = new System.Drawing.Point(704, 420);
            this.lstCart.MultiSelect = false;
            this.lstCart.Name = "lstCart";
            this.lstCart.Size = new System.Drawing.Size(257, 288);
            this.lstCart.TabIndex = 21;
            this.lstCart.UseCompatibleStateImageBehavior = false;
            this.lstCart.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.lstCart_ItemSelectionChanged);
            this.lstCart.Click += new System.EventHandler(this.lstCart_Click);
            this.lstCart.Leave += new System.EventHandler(this.lstCart_Leave);
            // 
            // lblProductCategory
            // 
            this.lblProductCategory.AutoSize = true;
            this.lblProductCategory.Location = new System.Drawing.Point(704, 224);
            this.lblProductCategory.Name = "lblProductCategory";
            this.lblProductCategory.Size = new System.Drawing.Size(91, 13);
            this.lblProductCategory.TabIndex = 22;
            this.lblProductCategory.Text = "Product category:";
            // 
            // checkOutButton
            // 
            this.checkOutButton.AutoSize = true;
            this.checkOutButton.Enabled = false;
            this.checkOutButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkOutButton.Location = new System.Drawing.Point(894, 795);
            this.checkOutButton.Name = "checkOutButton";
            this.checkOutButton.Size = new System.Drawing.Size(84, 33);
            this.checkOutButton.TabIndex = 23;
            this.checkOutButton.Text = "Checkout";
            this.checkOutButton.UseVisualStyleBackColor = true;
            this.checkOutButton.Click += new System.EventHandler(this.btnCheckOut_Click);
            // 
            // cboProductCategorySearch
            // 
            this.cboProductCategorySearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboProductCategorySearch.FormattingEnabled = true;
            this.cboProductCategorySearch.Location = new System.Drawing.Point(801, 216);
            this.cboProductCategorySearch.Name = "cboProductCategorySearch";
            this.cboProductCategorySearch.Size = new System.Drawing.Size(149, 21);
            this.cboProductCategorySearch.TabIndex = 24;
            this.cboProductCategorySearch.SelectedIndexChanged += new System.EventHandler(this.cboCategory_SelectedIndexChanged);
            // 
            // btnRemoveProductFromOrder
            // 
            this.btnRemoveProductFromOrder.Enabled = false;
            this.btnRemoveProductFromOrder.Location = new System.Drawing.Point(754, 391);
            this.btnRemoveProductFromOrder.Name = "btnRemoveProductFromOrder";
            this.btnRemoveProductFromOrder.Size = new System.Drawing.Size(149, 23);
            this.btnRemoveProductFromOrder.TabIndex = 25;
            this.btnRemoveProductFromOrder.Text = "Remove product from order";
            this.btnRemoveProductFromOrder.UseVisualStyleBackColor = true;
            this.btnRemoveProductFromOrder.Click += new System.EventHandler(this.btnRemoveFromOrder_Click);
            // 
            // btnClearFilters
            // 
            this.btnClearFilters.Location = new System.Drawing.Point(704, 248);
            this.btnClearFilters.Name = "btnClearFilters";
            this.btnClearFilters.Size = new System.Drawing.Size(95, 23);
            this.btnClearFilters.TabIndex = 26;
            this.btnClearFilters.Text = "Clear filters";
            this.btnClearFilters.UseVisualStyleBackColor = true;
            this.btnClearFilters.Click += new System.EventHandler(this.btnRemoveFilters_Click);
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.AutoSize = true;
            this.lblTotalCost.Location = new System.Drawing.Point(736, 320);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(58, 13);
            this.lblTotalCost.TabIndex = 27;
            this.lblTotalCost.Text = "Total Cost:";
            // 
            // lblCreditRemaining
            // 
            this.lblCreditRemaining.AutoSize = true;
            this.lblCreditRemaining.Location = new System.Drawing.Point(704, 345);
            this.lblCreditRemaining.Name = "lblCreditRemaining";
            this.lblCreditRemaining.Size = new System.Drawing.Size(90, 13);
            this.lblCreditRemaining.TabIndex = 28;
            this.lblCreditRemaining.Text = "Credit Remaining:";
            // 
            // txtTotalCost
            // 
            this.txtTotalCost.Location = new System.Drawing.Point(797, 317);
            this.txtTotalCost.Name = "txtTotalCost";
            this.txtTotalCost.ReadOnly = true;
            this.txtTotalCost.Size = new System.Drawing.Size(134, 20);
            this.txtTotalCost.TabIndex = 29;
            this.txtTotalCost.Text = "R 0.00";
            // 
            // txtCreditRemaining
            // 
            this.txtCreditRemaining.BackColor = System.Drawing.SystemColors.Control;
            this.txtCreditRemaining.Location = new System.Drawing.Point(797, 345);
            this.txtCreditRemaining.Name = "txtCreditRemaining";
            this.txtCreditRemaining.ReadOnly = true;
            this.txtCreditRemaining.Size = new System.Drawing.Size(134, 20);
            this.txtCreditRemaining.TabIndex = 30;
            // 
            // poppelDatabaseDataSet1
            // 
            this.poppelDatabaseDataSet1.DataSetName = "PoppelDatabaseDataSet";
            this.poppelDatabaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cancelOrderButton
            // 
            this.cancelOrderButton.AutoSize = true;
            this.cancelOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cancelOrderButton.Location = new System.Drawing.Point(686, 795);
            this.cancelOrderButton.Name = "cancelOrderButton";
            this.cancelOrderButton.Size = new System.Drawing.Size(83, 33);
            this.cancelOrderButton.TabIndex = 31;
            this.cancelOrderButton.Text = "Cancel";
            this.cancelOrderButton.UseVisualStyleBackColor = true;
            this.cancelOrderButton.Click += new System.EventHandler(this.btnCancelOrder_Click);
            // 
            // backButton
            // 
            this.backButton.AutoSize = true;
            this.backButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.Location = new System.Drawing.Point(789, 795);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(83, 33);
            this.backButton.TabIndex = 32;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Poppel.Properties.Resources.poppel_logo3;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(108, 83);
            this.pictureBox1.TabIndex = 38;
            this.pictureBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(704, 714);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 39;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(797, 714);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 40;
            this.button2.Text = "Back";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(886, 714);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 41;
            this.button3.Text = "Checkout";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.buttonCheckout_Click);
            // 
            // CreateOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImage = global::Poppel.Properties.Resources.poppel_logo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1025, 749);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.cancelOrderButton);
            this.Controls.Add(this.txtCreditRemaining);
            this.Controls.Add(this.txtTotalCost);
            this.Controls.Add(this.lblCreditRemaining);
            this.Controls.Add(this.lblTotalCost);
            this.Controls.Add(this.btnClearFilters);
            this.Controls.Add(this.btnRemoveProductFromOrder);
            this.Controls.Add(this.cboProductCategorySearch);
            this.Controls.Add(this.checkOutButton);
            this.Controls.Add(this.lblProductCategory);
            this.Controls.Add(this.lstCart);
            this.Controls.Add(this.lblCart);
            this.Controls.Add(this.txtProductNameSearch);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.headerLabel);
            this.Controls.Add(this.lblFilterAvailableProducts);
            this.Controls.Add(this.flpStockItems);
            this.Name = "CreateOrder";
            this.Text = "Create an Order";
            ((System.ComponentModel.ISupportInitialize)(this.poppelDatabaseDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flpStockItems;
        private System.Windows.Forms.Label lblFilterAvailableProducts;
        private System.Windows.Forms.Label headerLabel;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.TextBox txtProductNameSearch;
        private System.Windows.Forms.Label lblCart;
        private System.Windows.Forms.ListView lstCart;
        private System.Windows.Forms.Label lblProductCategory;
        private System.Windows.Forms.Button checkOutButton;
        private System.Windows.Forms.ComboBox cboProductCategorySearch;
        private System.Windows.Forms.Button btnRemoveProductFromOrder;
        private System.Windows.Forms.Button btnClearFilters;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.Label lblCreditRemaining;
        private System.Windows.Forms.TextBox txtTotalCost;
        private System.Windows.Forms.TextBox txtCreditRemaining;
        private PoppelDatabaseDataSet poppelDatabaseDataSet1;
        private System.Windows.Forms.Button cancelOrderButton;
        private System.Windows.Forms.Button backButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
    }
}