﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Poppel.Login;
using Poppel.Domain;

namespace Poppel.PresentationLayer
{
    public partial class Login : Form
    {
        private LoginController loginController;
        private bool loginClosed;

        #region Constructor
        public Login()
        {
            InitializeComponent();
            loginController = new LoginController();
            loginClosed = false;           
        }
        #endregion

        #region Form Events
        private void Login_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (!loginClosed)
            {
                Application.Exit();
            }
        }
        #endregion

        #region Button
        private void btnLogin_Click(object sender, EventArgs e)
        {
            lblErrorLogin.Visible = false;
            Employee employee = loginController.Login(txtEmployeeID.Text, txtPassword.Text);
            if(employee!=null)
            {
                PoppelMDIParent mainForm = new PoppelMDIParent(employee);
                
                mainForm.Show();
                loginClosed = true;
                this.Close();
             //  Application.Run();
            }
            else
            {
                lblErrorLogin.Text = "Username or password was incorrect.";
                lblErrorLogin.Visible = true;
            }
        }
        #endregion
    }
}
