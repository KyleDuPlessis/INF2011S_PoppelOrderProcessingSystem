﻿namespace Poppel.PresentationLayer
{
    partial class CustomerManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCustomerManagement = new System.Windows.Forms.Label();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.gboCustomer = new System.Windows.Forms.GroupBox();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtCustCode = new System.Windows.Forms.MaskedTextBox();
            this.lblCustNotFound = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnEditCustomer = new System.Windows.Forms.Button();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.lblStreet = new System.Windows.Forms.Label();
            this.lblSuburb = new System.Windows.Forms.Label();
            this.txtSuburb = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.lblPostalCode = new System.Windows.Forms.Label();
            this.txtPostalCode = new System.Windows.Forms.TextBox();
            this.lblErrorStreet = new System.Windows.Forms.Label();
            this.lblErrorSuburb = new System.Windows.Forms.Label();
            this.lblErrorCity = new System.Windows.Forms.Label();
            this.lblErrorPostalCode = new System.Windows.Forms.Label();
            this.gboDeliveryAddress = new System.Windows.Forms.GroupBox();
            this.txtTown = new System.Windows.Forms.TextBox();
            this.lblErrorTown = new System.Windows.Forms.Label();
            this.lblTown = new System.Windows.Forms.Label();
            this.lblErrorProvince = new System.Windows.Forms.Label();
            this.txtProvince = new System.Windows.Forms.TextBox();
            this.lblProvince = new System.Windows.Forms.Label();
            this.lblErrorEdit = new System.Windows.Forms.Label();
            this.btnDeleteCustomer = new System.Windows.Forms.Button();
            this.btnCancelOrder = new System.Windows.Forms.Button();
            this.pbPoppelLogo = new System.Windows.Forms.PictureBox();
            this.gboCustomerCredit = new System.Windows.Forms.GroupBox();
            this.lblErrorCreditRemaining = new System.Windows.Forms.Label();
            this.lblErrorTotalCreditLimit = new System.Windows.Forms.Label();
            this.txtTotalCreditLimit = new System.Windows.Forms.TextBox();
            this.lblTotalCreditLimit = new System.Windows.Forms.Label();
            this.txtCreditRemaining = new System.Windows.Forms.TextBox();
            this.lblCreditRemaining = new System.Windows.Forms.Label();
            this.gboCustomerDetails = new System.Windows.Forms.GroupBox();
            this.lblErrorPhoneNumber = new System.Windows.Forms.Label();
            this.txtPhoneNumber = new System.Windows.Forms.MaskedTextBox();
            this.lblErrorEmailAddress = new System.Windows.Forms.Label();
            this.lblErrorLastName = new System.Windows.Forms.Label();
            this.lblErrorFirstName = new System.Windows.Forms.Label();
            this.txtEmailAddress = new System.Windows.Forms.TextBox();
            this.lblEmailAddress = new System.Windows.Forms.Label();
            this.lblPhoneNumber = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.lstCustomer = new System.Windows.Forms.ListView();
            this.gboCustomer.SuspendLayout();
            this.gboDeliveryAddress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).BeginInit();
            this.gboCustomerCredit.SuspendLayout();
            this.gboCustomerDetails.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCustomerManagement
            // 
            this.lblCustomerManagement.AutoSize = true;
            this.lblCustomerManagement.Font = new System.Drawing.Font("Poor Richard", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerManagement.ForeColor = System.Drawing.Color.Orchid;
            this.lblCustomerManagement.Location = new System.Drawing.Point(257, 37);
            this.lblCustomerManagement.Name = "lblCustomerManagement";
            this.lblCustomerManagement.Size = new System.Drawing.Size(290, 33);
            this.lblCustomerManagement.TabIndex = 14;
            this.lblCustomerManagement.Text = "Customer Management";
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Location = new System.Drawing.Point(6, 22);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(68, 13);
            this.lblCustomerID.TabIndex = 0;
            this.lblCustomerID.Text = "Customer ID:";
            // 
            // gboCustomer
            // 
            this.gboCustomer.Controls.Add(this.btnClear);
            this.gboCustomer.Controls.Add(this.txtCustCode);
            this.gboCustomer.Controls.Add(this.lblCustNotFound);
            this.gboCustomer.Controls.Add(this.btnSearch);
            this.gboCustomer.Controls.Add(this.lblCustomerID);
            this.gboCustomer.Location = new System.Drawing.Point(12, 102);
            this.gboCustomer.Name = "gboCustomer";
            this.gboCustomer.Size = new System.Drawing.Size(674, 95);
            this.gboCustomer.TabIndex = 0;
            this.gboCustomer.TabStop = false;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(200, 58);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(75, 23);
            this.btnClear.TabIndex = 3;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            // 
            // txtCustCode
            // 
            this.txtCustCode.Location = new System.Drawing.Point(93, 19);
            this.txtCustCode.Mask = "LLLLLL000";
            this.txtCustCode.Name = "txtCustCode";
            this.txtCustCode.Size = new System.Drawing.Size(227, 20);
            this.txtCustCode.TabIndex = 1;
            this.txtCustCode.Leave += new System.EventHandler(this.txtCustCode_Leave);
            // 
            // lblCustNotFound
            // 
            this.lblCustNotFound.AutoSize = true;
            this.lblCustNotFound.BackColor = System.Drawing.Color.Transparent;
            this.lblCustNotFound.ForeColor = System.Drawing.Color.Red;
            this.lblCustNotFound.Location = new System.Drawing.Point(336, 19);
            this.lblCustNotFound.Name = "lblCustNotFound";
            this.lblCustNotFound.Size = new System.Drawing.Size(70, 13);
            this.lblCustNotFound.TabIndex = 20;
            this.lblCustNotFound.Text = "<Error Label>";
            this.lblCustNotFound.Visible = false;
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(99, 58);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(75, 23);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(115, 641);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 31);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnEditCustomer
            // 
            this.btnEditCustomer.Enabled = false;
            this.btnEditCustomer.Location = new System.Drawing.Point(205, 641);
            this.btnEditCustomer.Name = "btnEditCustomer";
            this.btnEditCustomer.Size = new System.Drawing.Size(99, 31);
            this.btnEditCustomer.TabIndex = 3;
            this.btnEditCustomer.Text = "Edit Customer";
            this.btnEditCustomer.UseVisualStyleBackColor = true;
            this.btnEditCustomer.Click += new System.EventHandler(this.btnEditCustomer_Click);
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.Enabled = false;
            this.btnPlaceOrder.Location = new System.Drawing.Point(503, 641);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(99, 31);
            this.btnPlaceOrder.TabIndex = 1;
            this.btnPlaceOrder.Text = "Place Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = true;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(120, 19);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.ReadOnly = true;
            this.txtStreet.Size = new System.Drawing.Size(341, 20);
            this.txtStreet.TabIndex = 5;
            this.txtStreet.Leave += new System.EventHandler(this.txtStreet_Leave);
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Location = new System.Drawing.Point(70, 22);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(38, 13);
            this.lblStreet.TabIndex = 4;
            this.lblStreet.Text = "Street:";
            // 
            // lblSuburb
            // 
            this.lblSuburb.AutoSize = true;
            this.lblSuburb.Location = new System.Drawing.Point(69, 73);
            this.lblSuburb.Name = "lblSuburb";
            this.lblSuburb.Size = new System.Drawing.Size(37, 13);
            this.lblSuburb.TabIndex = 6;
            this.lblSuburb.Text = "Town:";
            // 
            // txtSuburb
            // 
            this.txtSuburb.Location = new System.Drawing.Point(118, 70);
            this.txtSuburb.Name = "txtSuburb";
            this.txtSuburb.ReadOnly = true;
            this.txtSuburb.Size = new System.Drawing.Size(341, 20);
            this.txtSuburb.TabIndex = 7;
            this.txtSuburb.Leave += new System.EventHandler(this.txtSuburb_Leave);
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(79, 99);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(27, 13);
            this.lblCity.TabIndex = 8;
            this.lblCity.Text = "City:";
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(118, 96);
            this.txtCity.Name = "txtCity";
            this.txtCity.ReadOnly = true;
            this.txtCity.Size = new System.Drawing.Size(341, 20);
            this.txtCity.TabIndex = 9;
            this.txtCity.Leave += new System.EventHandler(this.txtCity_Leave);
            // 
            // lblPostalCode
            // 
            this.lblPostalCode.AutoSize = true;
            this.lblPostalCode.Location = new System.Drawing.Point(53, 150);
            this.lblPostalCode.Name = "lblPostalCode";
            this.lblPostalCode.Size = new System.Drawing.Size(67, 13);
            this.lblPostalCode.TabIndex = 12;
            this.lblPostalCode.Text = "Postal Code:";
            this.lblPostalCode.UseWaitCursor = true;
            // 
            // txtPostalCode
            // 
            this.txtPostalCode.Location = new System.Drawing.Point(118, 147);
            this.txtPostalCode.Name = "txtPostalCode";
            this.txtPostalCode.ReadOnly = true;
            this.txtPostalCode.Size = new System.Drawing.Size(100, 20);
            this.txtPostalCode.TabIndex = 13;
            this.txtPostalCode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.postalCodeTextBox_KeyPress);
            this.txtPostalCode.Leave += new System.EventHandler(this.postalCodeTextBox_Leave);
            // 
            // lblErrorStreet
            // 
            this.lblErrorStreet.AutoSize = true;
            this.lblErrorStreet.ForeColor = System.Drawing.Color.Red;
            this.lblErrorStreet.Location = new System.Drawing.Point(467, 22);
            this.lblErrorStreet.Name = "lblErrorStreet";
            this.lblErrorStreet.Size = new System.Drawing.Size(70, 13);
            this.lblErrorStreet.TabIndex = 28;
            this.lblErrorStreet.Text = "<Error Label>";
            this.lblErrorStreet.Visible = false;
            // 
            // lblErrorSuburb
            // 
            this.lblErrorSuburb.AutoSize = true;
            this.lblErrorSuburb.ForeColor = System.Drawing.Color.Red;
            this.lblErrorSuburb.Location = new System.Drawing.Point(463, 73);
            this.lblErrorSuburb.Name = "lblErrorSuburb";
            this.lblErrorSuburb.Size = new System.Drawing.Size(70, 13);
            this.lblErrorSuburb.TabIndex = 33;
            this.lblErrorSuburb.Text = "<Error Label>";
            this.lblErrorSuburb.Visible = false;
            // 
            // lblErrorCity
            // 
            this.lblErrorCity.AutoSize = true;
            this.lblErrorCity.ForeColor = System.Drawing.Color.Red;
            this.lblErrorCity.Location = new System.Drawing.Point(465, 99);
            this.lblErrorCity.Name = "lblErrorCity";
            this.lblErrorCity.Size = new System.Drawing.Size(70, 13);
            this.lblErrorCity.TabIndex = 34;
            this.lblErrorCity.Text = "<Error Label>";
            this.lblErrorCity.Visible = false;
            // 
            // lblErrorPostalCode
            // 
            this.lblErrorPostalCode.AutoSize = true;
            this.lblErrorPostalCode.ForeColor = System.Drawing.Color.Red;
            this.lblErrorPostalCode.Location = new System.Drawing.Point(224, 150);
            this.lblErrorPostalCode.Name = "lblErrorPostalCode";
            this.lblErrorPostalCode.Size = new System.Drawing.Size(70, 13);
            this.lblErrorPostalCode.TabIndex = 35;
            this.lblErrorPostalCode.Text = "<Error Label>";
            this.lblErrorPostalCode.Visible = false;
            // 
            // gboDeliveryAddress
            // 
            this.gboDeliveryAddress.Controls.Add(this.txtTown);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorTown);
            this.gboDeliveryAddress.Controls.Add(this.lblTown);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorProvince);
            this.gboDeliveryAddress.Controls.Add(this.txtProvince);
            this.gboDeliveryAddress.Controls.Add(this.lblProvince);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorPostalCode);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorCity);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorSuburb);
            this.gboDeliveryAddress.Controls.Add(this.lblErrorStreet);
            this.gboDeliveryAddress.Controls.Add(this.txtPostalCode);
            this.gboDeliveryAddress.Controls.Add(this.lblPostalCode);
            this.gboDeliveryAddress.Controls.Add(this.txtCity);
            this.gboDeliveryAddress.Controls.Add(this.lblCity);
            this.gboDeliveryAddress.Controls.Add(this.txtSuburb);
            this.gboDeliveryAddress.Controls.Add(this.lblSuburb);
            this.gboDeliveryAddress.Controls.Add(this.lblStreet);
            this.gboDeliveryAddress.Controls.Add(this.txtStreet);
            this.gboDeliveryAddress.Location = new System.Drawing.Point(12, 338);
            this.gboDeliveryAddress.Name = "gboDeliveryAddress";
            this.gboDeliveryAddress.Size = new System.Drawing.Size(674, 174);
            this.gboDeliveryAddress.TabIndex = 7;
            this.gboDeliveryAddress.TabStop = false;
            this.gboDeliveryAddress.Text = "Delivery Address";
            this.gboDeliveryAddress.Visible = false;
            // 
            // txtTown
            // 
            this.txtTown.Location = new System.Drawing.Point(119, 44);
            this.txtTown.Name = "txtTown";
            this.txtTown.ReadOnly = true;
            this.txtTown.Size = new System.Drawing.Size(341, 20);
            this.txtTown.TabIndex = 51;
            // 
            // lblErrorTown
            // 
            this.lblErrorTown.AutoSize = true;
            this.lblErrorTown.ForeColor = System.Drawing.Color.Red;
            this.lblErrorTown.Location = new System.Drawing.Point(465, 47);
            this.lblErrorTown.Name = "lblErrorTown";
            this.lblErrorTown.Size = new System.Drawing.Size(70, 13);
            this.lblErrorTown.TabIndex = 50;
            this.lblErrorTown.Text = "<Error Label>";
            this.lblErrorTown.Visible = false;
            // 
            // lblTown
            // 
            this.lblTown.AutoSize = true;
            this.lblTown.Location = new System.Drawing.Point(62, 47);
            this.lblTown.Name = "lblTown";
            this.lblTown.Size = new System.Drawing.Size(44, 13);
            this.lblTown.TabIndex = 49;
            this.lblTown.Text = "Suburb:";
            // 
            // lblErrorProvince
            // 
            this.lblErrorProvince.AutoSize = true;
            this.lblErrorProvince.ForeColor = System.Drawing.Color.Red;
            this.lblErrorProvince.Location = new System.Drawing.Point(465, 124);
            this.lblErrorProvince.Name = "lblErrorProvince";
            this.lblErrorProvince.Size = new System.Drawing.Size(70, 13);
            this.lblErrorProvince.TabIndex = 38;
            this.lblErrorProvince.Text = "<Error Label>";
            this.lblErrorProvince.Visible = false;
            // 
            // txtProvince
            // 
            this.txtProvince.Location = new System.Drawing.Point(118, 121);
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.ReadOnly = true;
            this.txtProvince.Size = new System.Drawing.Size(341, 20);
            this.txtProvince.TabIndex = 11;
            this.txtProvince.Leave += new System.EventHandler(this.txtProvince_Leave);
            // 
            // lblProvince
            // 
            this.lblProvince.AutoSize = true;
            this.lblProvince.Location = new System.Drawing.Point(54, 124);
            this.lblProvince.Name = "lblProvince";
            this.lblProvince.Size = new System.Drawing.Size(52, 13);
            this.lblProvince.TabIndex = 10;
            this.lblProvince.Text = "Province:";
            // 
            // lblErrorEdit
            // 
            this.lblErrorEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblErrorEdit.ForeColor = System.Drawing.Color.Red;
            this.lblErrorEdit.Location = new System.Drawing.Point(220, 606);
            this.lblErrorEdit.Name = "lblErrorEdit";
            this.lblErrorEdit.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblErrorEdit.Size = new System.Drawing.Size(299, 32);
            this.lblErrorEdit.TabIndex = 36;
            this.lblErrorEdit.Text = "<Error Label>";
            this.lblErrorEdit.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblErrorEdit.Visible = false;
            // 
            // btnDeleteCustomer
            // 
            this.btnDeleteCustomer.Enabled = false;
            this.btnDeleteCustomer.Location = new System.Drawing.Point(310, 641);
            this.btnDeleteCustomer.Name = "btnDeleteCustomer";
            this.btnDeleteCustomer.Size = new System.Drawing.Size(99, 31);
            this.btnDeleteCustomer.TabIndex = 4;
            this.btnDeleteCustomer.Text = "Delete Customer";
            this.btnDeleteCustomer.UseVisualStyleBackColor = true;
            // 
            // btnCancelOrder
            // 
            this.btnCancelOrder.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancelOrder.Location = new System.Drawing.Point(415, 641);
            this.btnCancelOrder.Name = "btnCancelOrder";
            this.btnCancelOrder.Size = new System.Drawing.Size(84, 31);
            this.btnCancelOrder.TabIndex = 2;
            this.btnCancelOrder.Text = "Cancel Order";
            this.btnCancelOrder.UseVisualStyleBackColor = true;
            // 
            // pbPoppelLogo
            // 
            this.pbPoppelLogo.Image = global::Poppel.Properties.Resources.poppel_logo3;
            this.pbPoppelLogo.Location = new System.Drawing.Point(29, 13);
            this.pbPoppelLogo.Name = "pbPoppelLogo";
            this.pbPoppelLogo.Size = new System.Drawing.Size(108, 83);
            this.pbPoppelLogo.TabIndex = 37;
            this.pbPoppelLogo.TabStop = false;
            // 
            // gboCustomerCredit
            // 
            this.gboCustomerCredit.Controls.Add(this.lblErrorCreditRemaining);
            this.gboCustomerCredit.Controls.Add(this.lblErrorTotalCreditLimit);
            this.gboCustomerCredit.Controls.Add(this.txtTotalCreditLimit);
            this.gboCustomerCredit.Controls.Add(this.lblTotalCreditLimit);
            this.gboCustomerCredit.Controls.Add(this.txtCreditRemaining);
            this.gboCustomerCredit.Controls.Add(this.lblCreditRemaining);
            this.gboCustomerCredit.Location = new System.Drawing.Point(12, 524);
            this.gboCustomerCredit.Name = "gboCustomerCredit";
            this.gboCustomerCredit.Size = new System.Drawing.Size(675, 70);
            this.gboCustomerCredit.TabIndex = 6;
            this.gboCustomerCredit.TabStop = false;
            this.gboCustomerCredit.Text = "Customer Credit";
            this.gboCustomerCredit.Visible = false;
            // 
            // lblErrorCreditRemaining
            // 
            this.lblErrorCreditRemaining.AutoSize = true;
            this.lblErrorCreditRemaining.ForeColor = System.Drawing.Color.Red;
            this.lblErrorCreditRemaining.Location = new System.Drawing.Point(466, 50);
            this.lblErrorCreditRemaining.Name = "lblErrorCreditRemaining";
            this.lblErrorCreditRemaining.Size = new System.Drawing.Size(70, 13);
            this.lblErrorCreditRemaining.TabIndex = 37;
            this.lblErrorCreditRemaining.Text = "<Error Label>";
            this.lblErrorCreditRemaining.Visible = false;
            // 
            // lblErrorTotalCreditLimit
            // 
            this.lblErrorTotalCreditLimit.AutoSize = true;
            this.lblErrorTotalCreditLimit.ForeColor = System.Drawing.Color.Red;
            this.lblErrorTotalCreditLimit.Location = new System.Drawing.Point(465, 23);
            this.lblErrorTotalCreditLimit.Name = "lblErrorTotalCreditLimit";
            this.lblErrorTotalCreditLimit.Size = new System.Drawing.Size(70, 13);
            this.lblErrorTotalCreditLimit.TabIndex = 36;
            this.lblErrorTotalCreditLimit.Text = "<Error Label>";
            this.lblErrorTotalCreditLimit.Visible = false;
            // 
            // txtTotalCreditLimit
            // 
            this.txtTotalCreditLimit.Location = new System.Drawing.Point(118, 23);
            this.txtTotalCreditLimit.Name = "txtTotalCreditLimit";
            this.txtTotalCreditLimit.ReadOnly = true;
            this.txtTotalCreditLimit.Size = new System.Drawing.Size(341, 20);
            this.txtTotalCreditLimit.TabIndex = 1;
            this.txtTotalCreditLimit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.creditLimitTextBox_KeyPress);
            this.txtTotalCreditLimit.Leave += new System.EventHandler(this.creditLimitTextBox_Leave);
            // 
            // lblTotalCreditLimit
            // 
            this.lblTotalCreditLimit.AutoSize = true;
            this.lblTotalCreditLimit.Location = new System.Drawing.Point(25, 26);
            this.lblTotalCreditLimit.Name = "lblTotalCreditLimit";
            this.lblTotalCreditLimit.Size = new System.Drawing.Size(88, 13);
            this.lblTotalCreditLimit.TabIndex = 0;
            this.lblTotalCreditLimit.Text = "Total Credit Limit:";
            // 
            // txtCreditRemaining
            // 
            this.txtCreditRemaining.Location = new System.Drawing.Point(119, 47);
            this.txtCreditRemaining.Name = "txtCreditRemaining";
            this.txtCreditRemaining.ReadOnly = true;
            this.txtCreditRemaining.Size = new System.Drawing.Size(341, 20);
            this.txtCreditRemaining.TabIndex = 3;
            // 
            // lblCreditRemaining
            // 
            this.lblCreditRemaining.AutoSize = true;
            this.lblCreditRemaining.Location = new System.Drawing.Point(20, 50);
            this.lblCreditRemaining.Name = "lblCreditRemaining";
            this.lblCreditRemaining.Size = new System.Drawing.Size(93, 13);
            this.lblCreditRemaining.TabIndex = 2;
            this.lblCreditRemaining.Text = " Credit Remaining:";
            // 
            // gboCustomerDetails
            // 
            this.gboCustomerDetails.Controls.Add(this.lblErrorPhoneNumber);
            this.gboCustomerDetails.Controls.Add(this.txtPhoneNumber);
            this.gboCustomerDetails.Controls.Add(this.lblErrorEmailAddress);
            this.gboCustomerDetails.Controls.Add(this.lblErrorLastName);
            this.gboCustomerDetails.Controls.Add(this.lblErrorFirstName);
            this.gboCustomerDetails.Controls.Add(this.txtEmailAddress);
            this.gboCustomerDetails.Controls.Add(this.lblEmailAddress);
            this.gboCustomerDetails.Controls.Add(this.lblPhoneNumber);
            this.gboCustomerDetails.Controls.Add(this.txtLastName);
            this.gboCustomerDetails.Controls.Add(this.lblLastName);
            this.gboCustomerDetails.Controls.Add(this.txtFirstName);
            this.gboCustomerDetails.Controls.Add(this.lblFirstName);
            this.gboCustomerDetails.ForeColor = System.Drawing.SystemColors.ControlText;
            this.gboCustomerDetails.Location = new System.Drawing.Point(12, 199);
            this.gboCustomerDetails.Name = "gboCustomerDetails";
            this.gboCustomerDetails.Size = new System.Drawing.Size(674, 133);
            this.gboCustomerDetails.TabIndex = 5;
            this.gboCustomerDetails.TabStop = false;
            this.gboCustomerDetails.Text = "Customer Details";
            this.gboCustomerDetails.Visible = false;
            // 
            // lblErrorPhoneNumber
            // 
            this.lblErrorPhoneNumber.AutoSize = true;
            this.lblErrorPhoneNumber.ForeColor = System.Drawing.Color.Red;
            this.lblErrorPhoneNumber.Location = new System.Drawing.Point(466, 80);
            this.lblErrorPhoneNumber.Name = "lblErrorPhoneNumber";
            this.lblErrorPhoneNumber.Size = new System.Drawing.Size(70, 13);
            this.lblErrorPhoneNumber.TabIndex = 28;
            this.lblErrorPhoneNumber.Text = "<Error Label>";
            this.lblErrorPhoneNumber.Visible = false;
            // 
            // txtPhoneNumber
            // 
            this.txtPhoneNumber.Location = new System.Drawing.Point(119, 77);
            this.txtPhoneNumber.Mask = "(000) 000-0000";
            this.txtPhoneNumber.Name = "txtPhoneNumber";
            this.txtPhoneNumber.ReadOnly = true;
            this.txtPhoneNumber.Size = new System.Drawing.Size(341, 20);
            this.txtPhoneNumber.TabIndex = 5;
            this.txtPhoneNumber.Leave += new System.EventHandler(this.phoneNumberMaskBox_Leave);
            // 
            // lblErrorEmailAddress
            // 
            this.lblErrorEmailAddress.AutoSize = true;
            this.lblErrorEmailAddress.ForeColor = System.Drawing.Color.Red;
            this.lblErrorEmailAddress.Location = new System.Drawing.Point(466, 106);
            this.lblErrorEmailAddress.Name = "lblErrorEmailAddress";
            this.lblErrorEmailAddress.Size = new System.Drawing.Size(70, 13);
            this.lblErrorEmailAddress.TabIndex = 27;
            this.lblErrorEmailAddress.Text = "<Error Label>";
            this.lblErrorEmailAddress.Visible = false;
            // 
            // lblErrorLastName
            // 
            this.lblErrorLastName.AutoSize = true;
            this.lblErrorLastName.ForeColor = System.Drawing.Color.Red;
            this.lblErrorLastName.Location = new System.Drawing.Point(466, 54);
            this.lblErrorLastName.Name = "lblErrorLastName";
            this.lblErrorLastName.Size = new System.Drawing.Size(70, 13);
            this.lblErrorLastName.TabIndex = 25;
            this.lblErrorLastName.Text = "<Error Label>";
            this.lblErrorLastName.Visible = false;
            // 
            // lblErrorFirstName
            // 
            this.lblErrorFirstName.AutoSize = true;
            this.lblErrorFirstName.ForeColor = System.Drawing.Color.Red;
            this.lblErrorFirstName.Location = new System.Drawing.Point(466, 28);
            this.lblErrorFirstName.Name = "lblErrorFirstName";
            this.lblErrorFirstName.Size = new System.Drawing.Size(70, 13);
            this.lblErrorFirstName.TabIndex = 24;
            this.lblErrorFirstName.Text = "<Error Label>";
            this.lblErrorFirstName.Visible = false;
            // 
            // txtEmailAddress
            // 
            this.txtEmailAddress.Location = new System.Drawing.Point(119, 103);
            this.txtEmailAddress.Name = "txtEmailAddress";
            this.txtEmailAddress.ReadOnly = true;
            this.txtEmailAddress.Size = new System.Drawing.Size(341, 20);
            this.txtEmailAddress.TabIndex = 7;
            this.txtEmailAddress.Leave += new System.EventHandler(this.emailAddressTextBox_Leave);
            // 
            // lblEmailAddress
            // 
            this.lblEmailAddress.AutoSize = true;
            this.lblEmailAddress.Location = new System.Drawing.Point(37, 106);
            this.lblEmailAddress.Name = "lblEmailAddress";
            this.lblEmailAddress.Size = new System.Drawing.Size(76, 13);
            this.lblEmailAddress.TabIndex = 6;
            this.lblEmailAddress.Text = "Email Address:";
            // 
            // lblPhoneNumber
            // 
            this.lblPhoneNumber.AutoSize = true;
            this.lblPhoneNumber.Location = new System.Drawing.Point(32, 77);
            this.lblPhoneNumber.Name = "lblPhoneNumber";
            this.lblPhoneNumber.Size = new System.Drawing.Size(81, 13);
            this.lblPhoneNumber.TabIndex = 4;
            this.lblPhoneNumber.Text = "Phone Number:";
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(119, 51);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.ReadOnly = true;
            this.txtLastName.Size = new System.Drawing.Size(341, 20);
            this.txtLastName.TabIndex = 3;
            this.txtLastName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.lastNameTextBox_KeyPress);
            this.txtLastName.Leave += new System.EventHandler(this.lastNameTextBox_Leave);
            // 
            // lblLastName
            // 
            this.lblLastName.AutoSize = true;
            this.lblLastName.Location = new System.Drawing.Point(52, 54);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(61, 13);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name:";
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(119, 25);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.ReadOnly = true;
            this.txtFirstName.Size = new System.Drawing.Size(341, 20);
            this.txtFirstName.TabIndex = 1;
            this.txtFirstName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.firstNameTestBox_KeyPress);
            this.txtFirstName.Leave += new System.EventHandler(this.firstNameTestBox_Leave);
            // 
            // lblFirstName
            // 
            this.lblFirstName.AutoSize = true;
            this.lblFirstName.Location = new System.Drawing.Point(53, 28);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(60, 13);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            // 
            // lstCustomer
            // 
            this.lstCustomer.BackColor = System.Drawing.SystemColors.Control;
            this.lstCustomer.Location = new System.Drawing.Point(16, 199);
            this.lstCustomer.Name = "lstCustomer";
            this.lstCustomer.Size = new System.Drawing.Size(666, 405);
            this.lstCustomer.TabIndex = 29;
            this.lstCustomer.UseCompatibleStateImageBehavior = false;
            // 
            // CustomerManagement
            // 
            this.AcceptButton = this.btnSearch;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Poppel.Properties.Resources.poppel_logo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(695, 522);
            this.Controls.Add(this.gboCustomerCredit);
            this.Controls.Add(this.gboCustomerDetails);
            this.Controls.Add(this.btnCancelOrder);
            this.Controls.Add(this.btnDeleteCustomer);
            this.Controls.Add(this.pbPoppelLogo);
            this.Controls.Add(this.lblErrorEdit);
            this.Controls.Add(this.btnPlaceOrder);
            this.Controls.Add(this.btnEditCustomer);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.gboCustomer);
            this.Controls.Add(this.lblCustomerManagement);
            this.Controls.Add(this.gboDeliveryAddress);
            this.Controls.Add(this.lstCustomer);
            this.Name = "CustomerManagement";
            this.Text = "Customer Management";
            this.gboCustomer.ResumeLayout(false);
            this.gboCustomer.PerformLayout();
            this.gboDeliveryAddress.ResumeLayout(false);
            this.gboDeliveryAddress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).EndInit();
            this.gboCustomerCredit.ResumeLayout(false);
            this.gboCustomerCredit.PerformLayout();
            this.gboCustomerDetails.ResumeLayout(false);
            this.gboCustomerDetails.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCustomerManagement;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.GroupBox gboCustomer;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnEditCustomer;
        private System.Windows.Forms.Button btnPlaceOrder;
        private System.Windows.Forms.Label lblCustNotFound;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.Label lblSuburb;
        private System.Windows.Forms.TextBox txtSuburb;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label lblPostalCode;
        private System.Windows.Forms.TextBox txtPostalCode;
        private System.Windows.Forms.Label lblErrorStreet;
        private System.Windows.Forms.Label lblErrorSuburb;
        private System.Windows.Forms.Label lblErrorCity;
        private System.Windows.Forms.Label lblErrorPostalCode;
        private System.Windows.Forms.GroupBox gboDeliveryAddress;
        private System.Windows.Forms.MaskedTextBox txtCustCode;
        private System.Windows.Forms.Label lblErrorEdit;
        private System.Windows.Forms.Label lblErrorProvince;
        private System.Windows.Forms.TextBox txtProvince;
        private System.Windows.Forms.Label lblProvince;
        private System.Windows.Forms.PictureBox pbPoppelLogo;
        private System.Windows.Forms.Button btnDeleteCustomer;
        private System.Windows.Forms.Button btnCancelOrder;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.GroupBox gboCustomerCredit;
        private System.Windows.Forms.Label lblErrorCreditRemaining;
        private System.Windows.Forms.Label lblErrorTotalCreditLimit;
        private System.Windows.Forms.TextBox txtTotalCreditLimit;
        private System.Windows.Forms.Label lblTotalCreditLimit;
        private System.Windows.Forms.TextBox txtCreditRemaining;
        private System.Windows.Forms.Label lblCreditRemaining;
        private System.Windows.Forms.GroupBox gboCustomerDetails;
        private System.Windows.Forms.Label lblErrorPhoneNumber;
        private System.Windows.Forms.MaskedTextBox txtPhoneNumber;
        private System.Windows.Forms.Label lblErrorEmailAddress;
        private System.Windows.Forms.Label lblErrorLastName;
        private System.Windows.Forms.Label lblErrorFirstName;
        private System.Windows.Forms.TextBox txtEmailAddress;
        private System.Windows.Forms.Label lblEmailAddress;
        private System.Windows.Forms.Label lblPhoneNumber;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.ListView lstCustomer;
        private System.Windows.Forms.TextBox txtTown;
        private System.Windows.Forms.Label lblErrorTown;
        private System.Windows.Forms.Label lblTown;
    }
}