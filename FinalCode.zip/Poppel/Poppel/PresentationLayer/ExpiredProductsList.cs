﻿using System;
using System.Windows.Forms;
using System.Collections.ObjectModel;
using Poppel.Order;

namespace Poppel.Report
{
    public partial class ExpiredProducts : Form
    {
        public Collection<StockItem> productList;
        public string date;
        ExpiredProductReport expiredProductController = new ExpiredProductReport();
        //private OrderController orderController;

        #region Properties
        public Collection<StockItem> Products
        {
            get { return productList; }
            set { productList = value; }
        }
        #endregion

        #region Constructor
        public ExpiredProducts()
        {
            this.Products = new Collection<StockItem>();
            InitializeComponent(); 
            lstProducts.View = View.Details;
            
            //lblEmployeeID.Text = orderController.Order.Employee.ID;
            lblDate.Text = DateTime.Today.Day + "-" + DateTime.Today.Month + "-" + DateTime.Today.Year;
        }
        #endregion

        #region ListView Events
        private void FillReport(string date)
        {
            lstProducts.Clear();
            this.Products = expiredProductController.GetStock(date);
            ListViewItem itemDetails;
            lblDate.Visible = true;
            lstProducts.Columns.Insert(0, "Item Rack Number", 100, HorizontalAlignment.Left);
            lstProducts.Columns.Insert(1, "Number Of Items In Stock", 100, HorizontalAlignment.Left);
            lstProducts.Columns.Insert(2, "Product Expiry Date", 100, HorizontalAlignment.Left);
            lstProducts.Columns.Insert(3, "Product Description", 150, HorizontalAlignment.Left);
            
            if(productList!=null && productList.Count!=0)
            {
                foreach (StockItem item in productList)
                {
                    itemDetails = new ListViewItem();
                    itemDetails.Text = item.ItemRackNumber;
                    itemDetails.SubItems.Add(item.ItemNumberInStock);
                    itemDetails.SubItems.Add(item.ItemExpiryDate);
                    itemDetails.SubItems.Add(item.ProductReference);
                    lstProducts.Items.Add(itemDetails);
                }
            }

            lstProducts.Refresh();
            lstProducts.GridLines = true;           
        }
        #endregion

        #region Calender
        private void clnPickDate_Click(object sender, DateRangeEventArgs e)
        {
            DateTime DateSelected = pickDateCalendar.SelectionRange.Start;
            lblDate.Text = DateSelected.Day + "-" + DateSelected.Month + "-" + DateSelected.Year;
            pickDateCalendar.Visible = false;
            date = DateSelected.Year + "-" + DateSelected.Month + "-" + DateSelected.Day; 
            Console.WriteLine(date);
            lstProducts.Visible = true;
            FillReport(date);
        }
        #endregion

        #region Buttons
        private void btnReset_Click(object sender, EventArgs e)
        {
            ExpiredProducts expiredList = new ExpiredProducts();
            expiredList.MdiParent = this.MdiParent;
            expiredList.StartPosition = FormStartPosition.CenterScreen;
            expiredList.Show();
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        #endregion
    }
}
