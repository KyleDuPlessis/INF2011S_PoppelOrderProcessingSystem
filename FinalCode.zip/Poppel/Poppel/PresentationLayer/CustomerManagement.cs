﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Poppel.CustomerMangement;
using Poppel.Domain;
using Poppel.Order;

namespace Poppel.PresentationLayer
{
    public partial class CustomerManagement : Form
    {
        private CustomerManangementController customerManagementController;
        private State editButtonState;
        private Collection<Customer> customerList;

        public enum State
        {
            editCustomer = 0,
            saveCustomer = 1
        }

        #region Constructor
        public CustomerManagement(CustomerManangementController custController)
        {
            InitializeComponent();

            customerManagementController = custController;
            txtCustCode.Select();
            editButtonState = State.editCustomer;
        }
        #endregion

        #region Search
        public void Search(string text)
        {
            SetLabelVisibility(false);
            gboDeliveryAddress.Visible = false;
            gboCustomerCredit.Visible = false;
            gboCustomerDetails.Visible = false;
            btnPlaceOrder.Enabled = false;
            btnCancelOrder.Enabled = false;
            if (!lblCustNotFound.Visible)
            {
                SetButtonState(State.editCustomer);

                if (text==null)
                {
                    Customer searchCustomer = customerManagementController.SearchCustomerByCustomerNumber(txtCustCode.Text.ToLower());
                    SetCustomerDetails(searchCustomer);
                }
                    else
                    {
                        txtCustCode.Text = text.ToLower();
                        Customer searchCustomer = customerManagementController.SearchCustomerByCustomerNumber(txtCustCode.Text.ToLower());
                        SetCustomerDetails(searchCustomer);
                    }

                    if (customerList != null)
                    {
                        lstCustomer.View = View.Details;
                        SetUpEmployeeListView(customerList);
                        lstCustomer.Focus();
                    }
            }
        }
        #endregion      
        
        #region ListView
        public void SetUpEmployeeListView(Collection<Customer> customerCollection)
        {
            ListViewItem customerDetails;

            //Clear current List View Control
            lstCustomer.Clear();

            //Set Up Columns of List View
            lstCustomer.Columns.Insert(0, "Customer Code", 85, HorizontalAlignment.Left);
            lstCustomer.Columns.Insert(1, "Name", 115, HorizontalAlignment.Left);
            lstCustomer.Columns.Insert(2, "Phone Number", 85, HorizontalAlignment.Left);
            lstCustomer.Columns.Insert(3, "Email", 130, HorizontalAlignment.Left);
            lstCustomer.Columns.Insert(4, "Address", 300, HorizontalAlignment.Left);


             //Add employee details to each ListView item 

            foreach (Customer customer in customerCollection)
            {
                customerDetails = new ListViewItem();
                customerDetails.Text = customer.ID;
                customerDetails.SubItems.Add(customer.NameToString());
                customerDetails.SubItems.Add(Person.FormatPhoneNumber(customer.PhoneNumber));
                customerDetails.SubItems.Add(customer.EmailAddress);
                customerDetails.SubItems.Add(customer.DeliveryAddressToString());
                lstCustomer.Items.Add(customerDetails);
            }

            lstCustomer.Refresh();
            lstCustomer.GridLines = true;

        }
        #endregion

        #region Utility
        private void SetCustomerDetails(Customer searchCustomer)
        {
            
            if (searchCustomer == null)
            {
                lblCustNotFound.Text = "The customer entered does not exist.";
                lblCustNotFound.Visible = true;
                btnEditCustomer.Enabled = false;

                gboCustomerCredit.Visible = false;
                gboCustomerDetails.Visible = false;
                gboDeliveryAddress.Visible = false;
            }
            else
            {
                lblCustNotFound.Visible = false;
                txtFirstName.Text = searchCustomer.FirstName;
                txtLastName.Text = searchCustomer.LastName;
                txtPhoneNumber.Text = searchCustomer.PhoneNumber;
                txtEmailAddress.Text = searchCustomer.EmailAddress;
                txtStreet.Text = searchCustomer.DeliveryAddress[0];
                txtTown.Text = searchCustomer.DeliveryAddress[1];
                txtSuburb.Text = searchCustomer.DeliveryAddress[2];
                txtCity.Text = searchCustomer.DeliveryAddress[3];
                txtProvince.Text = searchCustomer.DeliveryAddress[4];
                txtPostalCode.Text = searchCustomer.DeliveryAddress[5];
                txtCreditRemaining.Text = string.Format("{0:0.00}", searchCustomer.CreditLimit - searchCustomer.Credit);
                txtTotalCreditLimit.Text = string.Format("{0:0.00}", searchCustomer.CreditLimit);
                if(searchCustomer.Credit<searchCustomer.CreditLimit)
                {
                    btnPlaceOrder.Enabled = true;
                }
                else
                {
                    lblErrorCreditRemaining.Text = "Credit Limit Exceeded. No new orders can be added.";
                    lblErrorCreditRemaining.Visible = true;
                }

                btnCancelOrder.Enabled = true;
                gboCustomerCredit.Visible = true;
                gboCustomerDetails.Visible = true;
                gboDeliveryAddress.Visible = true;
                btnEditCustomer.Enabled = true;
                Customer customer = new Customer();
                if (CreateCustomer(customer))
                {
                    customerManagementController.Customer = customer;
                }
            }
        }

        private bool CreateCustomer(Customer customer)
        {

            Boolean correct = true;
            customer.ID = txtCustCode.Text.Trim();
            customer.FirstName = txtFirstName.Text.Trim();
            customer.LastName = txtLastName.Text.Trim();
            customer.PhoneNumber = Person.UnFormatPhoneNumber(txtPhoneNumber.Text);
            customer.EmailAddress = txtEmailAddress.Text;
            decimal temp = -1;
           
            temp = -1;
            Decimal.TryParse(txtTotalCreditLimit.Text.Trim(), out temp);
            if (temp == -1)
            {
                lblErrorEdit.Text = "An error occured converting credit limit.\nCheck credit limit format is correct.";
                lblErrorEdit.Visible = true;
                correct = false;
            }
            else
            {
                customer.CreditLimit = temp;
            }
            Decimal.TryParse(txtCreditRemaining.Text.Trim(), out temp);
            if (temp == -1)
            {
                lblErrorEdit.Text = "An error occured converting credit.";
                lblErrorEdit.Visible = true;
                correct = false;

            }
            else
            {
                customer.Credit = customer.CreditLimit-temp;
            }
            string[] address = new string[Person.ADDRESS_LENGTH];
            address[0] = txtStreet.Text.Trim();
            address[1] = txtTown.Text.Trim();
            address[2] = txtSuburb.Text.Trim();
            address[3] = txtCity.Text.Trim();
            address[4] = txtProvince.Text.Trim();
            address[5] = txtPostalCode.Text.Trim();

            customer.DeliveryAddress = address;

            return correct;
        }

        private void SetButtonState(State state)
        {
            if (state == State.editCustomer)
            {
                btnEditCustomer.Text = "Edit Customer";
                editButtonState = State.editCustomer;
            }
            else if (state == State.saveCustomer)
            {
                btnEditCustomer.Text = "Save Customer";
                editButtonState = State.saveCustomer;
            }

        }


        private bool IsCustomerDetailsValid()
        {
            if (lblErrorFirstName.Visible || lblErrorLastName.Visible || lblErrorPhoneNumber.Visible || lblErrorEmailAddress.Visible || lblErrorTotalCreditLimit.Visible || lblErrorPostalCode.Visible || lblErrorStreet.Visible || lblErrorSuburb.Visible || lblErrorCity.Visible)
            {
                return false;
            }
            return true;

        }

        private void SetLabelVisibility(bool visible)
        {
            lblErrorFirstName.Visible = visible;
            lblErrorLastName.Visible = visible;
            lblErrorPhoneNumber.Visible = visible;
            lblErrorEmailAddress.Visible = visible;
            lblErrorTotalCreditLimit.Visible = visible;
            lblErrorPostalCode.Visible = visible;
            lblErrorStreet.Visible = visible;
            lblErrorTown.Visible = visible;
            lblErrorSuburb.Visible = visible;
            lblErrorCity.Visible = visible;
            lblErrorProvince.Visible = visible;
            lblErrorCreditRemaining.Visible = visible;
        }

        private void SetReadOnly(bool set)
        {
            txtFirstName.ReadOnly = set;
            txtLastName.ReadOnly = set;
            txtPhoneNumber.ReadOnly = set;
            txtEmailAddress.ReadOnly = set;
            txtStreet.ReadOnly = set;
            txtTown.ReadOnly = set;
            txtSuburb.ReadOnly = set;
            txtCity.ReadOnly = set;
            txtProvince.ReadOnly = set;
            txtPostalCode.ReadOnly = set;
            txtTotalCreditLimit.ReadOnly = set;
        }
        #endregion

        #region Validation
        private void firstNameTestBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
                lblErrorFirstName.Text = "Numbers are not allowed in a name.";
                lblErrorFirstName.Visible = true;
            }
            else if (txtFirstName.Text.Length >= 60 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                lblErrorFirstName.Text = "Name length has been exceeded.\nNames can only be up to 60 characters.";
                lblErrorFirstName.Visible = true;
            }
            else
            {
                lblErrorFirstName.Visible = false;
            }
        }

        private void lastNameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
                lblErrorLastName.Text = "Numbers are not allowed in a name.";
                lblErrorLastName.Visible = true;
            }
            else if (txtLastName.Text.Length >= 60 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                lblErrorLastName.Text = "Name length has been exceeded.\nNames can only be up to 60 characters.";
                lblErrorLastName.Visible = true;
            }
            else
            {
                lblErrorLastName.Visible = false;
            }
        }


        private void phoneNumberMaskBox_Leave(object sender, EventArgs e)
        {

            if (txtPhoneNumber.Text != "(   )    -" && Person.UnFormatPhoneNumber(txtPhoneNumber.Text) == null)
            {
                Console.WriteLine(txtPhoneNumber.Text);
                lblErrorPhoneNumber.Text = "Phone number must contain 10 digits.";
                lblErrorPhoneNumber.Visible = true;
            }
            else if (txtPhoneNumber.Text.Equals("(   )    -") && txtEmailAddress.Text.Length == 0)
            {
                lblErrorPhoneNumber.Text = "Phone number or email address is required";
                lblErrorPhoneNumber.Visible = true;
            }
            else
            {
                lblErrorPhoneNumber.Visible = false;
            }
        }

        private void emailAddressTextBox_Leave(object sender, EventArgs e)
        {
            //http://www.codeproject.com/Questions/447172/Email-Mask-for-csharp-masktextbox
            //Checks if email address is in correct format.
            if (!System.Text.RegularExpressions.Regex.IsMatch(((TextBox)sender).Text, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$") && txtEmailAddress.Text.Length != 0)
            {
                lblErrorEmailAddress.Text = "Email address should be in the format:\nxyz@abc.com";
                lblErrorEmailAddress.Visible = true;
            }
            else if (txtPhoneNumber.Text.Equals("(   )    -") && txtEmailAddress.Text.Length == 0)
            {
                lblErrorPhoneNumber.Text = "Phone number or email address is required";
                lblErrorPhoneNumber.Visible = true;
            }
            else if (txtEmailAddress.Text.Length >= 60)
            {
                lblErrorEmailAddress.Text = "Email length has been exceeded.\nEmails can only be up to 60 characters.";
               lblErrorEmailAddress.Visible = true;
            }
            else
            {
                lblErrorEmailAddress.Visible = false;
            }

        }

        private void firstNameTestBox_Leave(object sender, EventArgs e)
        {
            int i = 0;
            bool stop = false;

            if (txtFirstName.Text.Length >= 60)
            {
                lblErrorFirstName.Text = "Name length has been exceeded.\nNames can only be up to 60 characters.";
                lblErrorFirstName.Visible = true;
                stop = true;
            }
            while (i < txtFirstName.Text.Length && !stop)
            {
                if (char.IsNumber(txtFirstName.Text[i]))
                {
                    lblErrorFirstName.Text = "Numbers are not allowed in a name.";
                    lblErrorFirstName.Visible = true;
                    stop = true;
                }
                i++;
            }
            if (!stop)
            {
                lblErrorFirstName.Visible = false;
            }
        }

        private void lastNameTextBox_Leave(object sender, EventArgs e)
        {
            int i = 0;
            bool stop = false;

            if (txtLastName.Text.Length >= 60)
            {
                lblErrorLastName.Text = "Name length has been exceeded.\nNames can only be up to 60 characters.";
                lblErrorLastName.Visible = true;
                stop = true;
            }
            while (i < txtLastName.Text.Length && !stop)
            {
                if (char.IsNumber(txtLastName.Text[i]))
                {
                    lblErrorLastName.Text = "Numbers are not allowed in a name.";
                    lblErrorLastName.Visible = true;
                    stop = true;
                }
                i++;
            }
            if (!stop)
            {
                lblErrorLastName.Visible = false;
            }
        }

        private void creditLimitTextBox_Leave(object sender, EventArgs e)
        {
            int i = 0;
            bool stop = false;
            int dotIndex = txtTotalCreditLimit.Text.IndexOf(".");
            if (dotIndex == -1 && txtTotalCreditLimit.Text.Length > 8)
            {
                lblErrorTotalCreditLimit.Text = "Credit limit can only be up to 8 digits.";
                lblErrorTotalCreditLimit.Visible = true;
                stop = true;
            }
            else if (dotIndex != -1 && txtTotalCreditLimit.Text.Length > 10)
            {
                lblErrorTotalCreditLimit.Text = "Credit limit can only be up to 8 digits.";
                lblErrorTotalCreditLimit.Visible = true;
                stop = true;
            }
            while (i < txtTotalCreditLimit.Text.Length && !stop)
            {
                if (!char.IsControl(txtTotalCreditLimit.Text[i]) && !char.IsDigit(txtTotalCreditLimit.Text[i]) && txtTotalCreditLimit.Text[i] != '.')
                {
                    lblErrorTotalCreditLimit.Text = "Only numbers and a '.' allowed.";
                    lblErrorTotalCreditLimit.Visible = true;
                    stop = true;
                }


                i++;
            }

            if (txtTotalCreditLimit.Text.IndexOf(".") != txtTotalCreditLimit.Text.LastIndexOf(".") && !stop)
            {
                lblErrorTotalCreditLimit.Text = "Only one '.' allowed.";
                lblErrorTotalCreditLimit.Visible = true;
                stop = true;
            }
            else if (dotIndex != -1 && txtTotalCreditLimit.Text.Substring(dotIndex).Length > 3 && !stop)
            {
                lblErrorTotalCreditLimit.Text = "Only two decimal places allowed.";
                lblErrorTotalCreditLimit.Visible = true;
                stop = true;
            }
            if (!stop)
            {
                lblErrorTotalCreditLimit.Visible = false;
            }
        }

        private void creditLimitTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {

            int index = (sender as TextBox).Text.IndexOf('.');
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                lblErrorTotalCreditLimit.Text = "Only numbers and a '.' allowed.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else if (e.KeyChar == '.' && index > -1)
            {
                lblErrorTotalCreditLimit.Text = "Only one '.' allowed.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else if (index != -1 && txtTotalCreditLimit.SelectionStart > index && txtTotalCreditLimit.Text.Substring(index).Length >= 3 && !char.IsControl(e.KeyChar))
            {

                int test = txtTotalCreditLimit.Text.Substring(index).Length;
                string test2 = txtTotalCreditLimit.Text.Substring(index);
                lblErrorTotalCreditLimit.Text = "Only two decimal places allowed.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else if (index == -1 && txtTotalCreditLimit.Text.Length > 8 && !char.IsControl(e.KeyChar))
            {
                lblErrorTotalCreditLimit.Text = "Name length has been exceeded.\nCredit limit can only be up to 8 digits.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else if (index != -1 && txtTotalCreditLimit.Text.Length > 10 && !char.IsControl(e.KeyChar))
            {
                lblErrorTotalCreditLimit.Text = "Name length has been exceeded.\nCredit limit can only be up to 8 digits.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else
            {
                lblErrorTotalCreditLimit.Visible = false;
            }

        }
        private void postalCodeTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtPostalCode.Text.Length >= 5 && !char.IsControl(e.KeyChar))
            {
                lblErrorPostalCode.Text = "Zip code can only be up to 5 digits.";
                lblErrorPostalCode.Visible = true;
                e.Handled = true;
            }

            else if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                lblErrorPostalCode.Text = "Only numbers allowed.";
                lblErrorPostalCode.Visible = true;
                e.Handled = true;
            }
            else
            {
                lblErrorPostalCode.Visible = false;
            }

        }

        private void postalCodeTextBox_Leave(object sender, EventArgs e)
        {
            bool stop = false;
            int i = 0;
            if (txtPostalCode.Text.Length > 5)
            {
                lblErrorPostalCode.Text = "Zip code can only be up to 5 digits.";
                lblErrorPostalCode.Visible = true;
                stop = true;
            }
            while (i < txtPostalCode.Text.Length && !stop)
            {
                if (!char.IsDigit(txtPostalCode.Text[i]))
                {

                    lblErrorPostalCode.Text = "Only numbers allowed.";
                    lblErrorPostalCode.Visible = true;
                    stop = true;
                }
                i++;
            }

            if (!stop)
            {
                lblErrorPostalCode.Visible = false;
            }
        }
        #endregion

        #region ListView
        private void lstCustomer_DoubleClick(object sender, EventArgs e)
        {
            if (lstCustomer.SelectedItems.Count != 0)
            {
                Customer temp = customerList[lstCustomer.FocusedItem.Index];
                SetCustomerDetails(temp);
                txtCustCode.Text = temp.ID;
            }
        }
        #endregion

        #region Textboxes
        private void txtCustCode_Leave(object sender, EventArgs e)
        {
            lblCustNotFound.Visible = false;
            if (txtCustCode.Text.Length != 9)
            {
                lblCustNotFound.Text = "Customer code must contain 9 characters.";
                lblCustNotFound.Visible = true;
            }           
        }

        private void txtStreet_Leave(object sender, EventArgs e)
        {
            if (txtStreet.Text.Length >= 60)
            {
                lblErrorStreet.Text = "Street length has been exceeded.\nStreets can only be up to 60 characters.";
                lblErrorStreet.Visible = true;
            }
            else
            {
                lblErrorStreet.Visible = false;
            }
        }

        private void txtTown_Leave(object sender, EventArgs e)
        {
            if (txtTown.Text.Length >= 60)
            {
                lblErrorTown.Text = "Town length has been exceeded.\nTown can only be up to 60 characters.";
                lblErrorTown.Visible = true;
            }
            else
            {
                lblErrorTown.Visible = false;
            }
        }

        private void txtSuburb_Leave(object sender, EventArgs e)
        {
            if (txtSuburb.Text.Length >= 60)
            {
                lblErrorSuburb.Text = "Suburb length has been exceeded.\nSuburbs can only be up to 60 characters.";
                lblErrorSuburb.Visible = true;
            }
            else
            {
                lblErrorSuburb.Visible = false;
            }
        }

        private void txtCity_Leave(object sender, EventArgs e)
        {
            if (txtCity.Text.Length >= 60)
            {
                lblErrorCity.Text = "City length has been exceeded.\nCity name can only be up to 60 characters.";
                lblErrorCity.Visible = true;
            }
            else
            {
                lblErrorCity.Visible = false;
            }
        }

        private void txtProvince_Leave(object sender, EventArgs e)
        {
            if (txtProvince.Text.Length >= 60)
            {
                lblErrorProvince.Text = "Province length has been exceeded.\nProvince can only be up to 60 characters.";
                lblErrorProvince.Visible = true;
            }
            else
            {
                lblErrorProvince.Visible = false;
            }
        }
        #endregion

        #region Buttons
        private void btnSearch_Click(object sender, EventArgs e)
        {
            Search(null);
        }

        private void btnEditCustomer_Click(object sender, EventArgs e)
        {
            lblErrorEdit.Visible = false;
            if (editButtonState == State.editCustomer)
            {

                SetReadOnly(false);
                SetButtonState(State.saveCustomer);
                txtFirstName.Select();
                btnEditCustomer.Text = "Save Customer";
            }
            else
            {
                if (IsCustomerDetailsValid())
                {
                    editButtonState = State.editCustomer;
                    btnEditCustomer.Text = "Edit Customer";
                    SetReadOnly(true);
                    Customer customer = new Customer();
                    if (CreateCustomer(customer))
                    {
                        customerManagementController.EditCustomer(customer);
                        customerManagementController.Customer = customer;
                    }
                }
                else
                {
                    lblErrorEdit.Text = "Customer Details count not be saved.\nFormat errors in customer details found.";
                    lblErrorEdit.Visible = true;
                }
            }
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            if (CreateCustomer(customer))
            {
                customerManagementController.Customer = customer;
            }
            OrderController controller = new OrderController(customerManagementController.Customer, customerManagementController.Employee);
            controller.CustomerManagementController = customerManagementController;
            CreateOrder createOrder = new CreateOrder(controller);
            createOrder.MdiParent = this.MdiParent;
            createOrder.StartPosition = FormStartPosition.CenterScreen;
            this.Close();
            createOrder.Show();          
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCancelOrder_Click(object sender, EventArgs e)
        {
            CancelOrder cancelOrder = new CancelOrder(customerManagementController);
            cancelOrder.MdiParent = this.MdiParent;
            cancelOrder.StartPosition = FormStartPosition.CenterScreen;
            this.Close();
            cancelOrder.Show();
        }
        #endregion
    }
}
