﻿using System;
using System.Windows.Forms;
using Poppel.Domain;
using Poppel.CustomerMangement;

namespace Poppel.PresentationLayer
{
    public partial class CreateCustomer : Form
    {
        private CustomerManangementController customerManagementController;

        #region Constructor
        public CreateCustomer(CustomerManangementController customerController)
        {
            InitializeComponent();
            customerManagementController = customerController;
            txtFirstName.Focus();
        }
        #endregion

        #region Form Events
        private bool CreateNewCustomer(Customer customer)
        {
            Boolean valid = true;
            customer.FirstName = txtFirstName.Text.Trim();
            customer.LastName = txtLastName.Text.Trim();
            
            customer.ID = customerManagementController.GenerateID(customer.FirstName, customer.LastName);
            

            if (Person.UnFormatPhoneNumber(txtPhoneNumber.Text) == null)
            {
                customer.PhoneNumber = "";
            }
            else
            {
                customer.PhoneNumber = Person.UnFormatPhoneNumber(txtPhoneNumber.Text);
            }

            customer.EmailAddress = txtEmailAddress.Text;

            if ((txtPhoneNumber.Text == null || txtPhoneNumber.Text == "") && (txtEmailAddress.Text == null || txtEmailAddress.Text == ""))
            {
                valid = false;
            }

            decimal temp = -1;
            customer.Credit = 0;
            Decimal.TryParse(txtTotalCreditLimit.Text.Trim(), out temp);

            if (temp == -1)
            {
                lblErrorCreateCustomer.Text = "Error: Please check total credit limit format is correct.";
                lblErrorCreateCustomer.Visible = true;
                valid = false;
            }
            else
            {
                customer.CreditLimit = temp;
            }

            string[] deliveryAddress = new string[Person.ADDRESS_LENGTH];

            deliveryAddress[0] = txtStreet.Text.Trim();
            deliveryAddress[1] = txtTown.Text.Trim();
            deliveryAddress[2] = txtSuburb.Text.Trim();
            deliveryAddress[3] = txtCity.Text.Trim();
            deliveryAddress[4] = txtProvince.Text.Trim();
            deliveryAddress[5] = txtPostalCode.Text.Trim();

            customer.DeliveryAddress = deliveryAddress;
            return valid;
        }
        #endregion

        #region Data Validation

        private bool isValidCustomerDetails()
        {

            if (lblErrorFirstName.Visible || lblErrorLastName.Visible || lblErrorPhoneNumber.Visible || lblErrorEmailAddress.Visible || lblErrorTotalCreditLimit.Visible || lblErrorPostalCode.Visible || lblErrorStreet.Visible || lblErrorSuburb.Visible || lblErrorCity.Visible || lblErrorTown.Visible || lblErrorProvince.Visible)
            {
                return false;
            }

            return true;

        }

        private void txtFirstName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
                lblErrorFirstName.Text = "Error: Numbers are not allowed in first name.";
                lblErrorFirstName.Visible = true;
            }
            else if (txtFirstName.Text.Length >= 50 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                lblErrorFirstName.Text = "Error: Length of first name has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorFirstName.Visible = true;
            }
            else
            {
                lblErrorFirstName.Visible = false;
            }
        }

        private void txtLastName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
                lblErrorLastName.Text = "Error: Numbers are not allowed in last name.";
                lblErrorLastName.Visible = true;
            }
            else if (txtLastName.Text.Length >= 50 && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
                lblErrorLastName.Text = "Error: Length of last name has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorLastName.Visible = true;
            }
            else
            {
                lblErrorLastName.Visible = false;
            }
        }


        private void txtPhoneNumber_Error(object sender, EventArgs e)
        {

            if (!txtPhoneNumber.Text.Equals("(   )    -") && Person.UnFormatPhoneNumber(txtPhoneNumber.Text) == null)
            {
                Console.WriteLine(txtPhoneNumber.Text);
                lblErrorPhoneNumber.Text = "Error: Phone number must be 10 digits long.";
                lblErrorPhoneNumber.Visible = true;
            }
            else if (txtPhoneNumber.Text.Equals("(   )    -") && txtEmailAddress.Text.Length == 0)
            {
                lblErrorPhoneNumber.Text = "Error: Phone number / email address is required";
                lblErrorPhoneNumber.Visible = true;
            }
            else
            {
                lblErrorPhoneNumber.Visible = false;
            }
        }

        private void txtEmailAddress_Error(object sender, EventArgs e)
        {
            
            if (!System.Text.RegularExpressions.Regex.IsMatch(((TextBox)sender).Text, @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$") && txtEmailAddress.Text.Length != 0)
            {
                lblErrorEmailAddress.Text = "Error: Email address should be in the format:\njohnny@gmail.com";
                lblErrorEmailAddress.Visible = true;
            }
            else if (txtPhoneNumber.Text.Equals("(   )    -") && txtEmailAddress.Text.Length == 0)
            {
                lblErrorPhoneNumber.Text = "Error: Phone number / email address is required";
                lblErrorPhoneNumber.Visible = true;
            }
            else if (txtEmailAddress.Text.Length >= 50)
            {
                lblErrorEmailAddress.Text = "Error: Length of email address has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorEmailAddress.Visible = true;
            }
            else
            {
                lblErrorEmailAddress.Visible = false;
            }

        }

        private void txtFirstName_Error(object sender, EventArgs e)
        {
            int i = 0;
            bool end = false;

            if (txtFirstName.Text.Length >= 50)
            {
                lblErrorFirstName.Text = "Error: Length of first name has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorFirstName.Visible = true;
                end = true;
            }
            else if (txtFirstName.Text.Length == 0)
            {

                lblErrorFirstName.Text = "Error: First name is a required field.";
                lblErrorFirstName.Visible = true;
                end = true;
            }
            while (i < txtFirstName.Text.Length && !end)
            {
                if (char.IsNumber(txtFirstName.Text[i]))
                {
                    lblErrorFirstName.Text = "Error: Numbers are not allowed in first name.";
                    lblErrorFirstName.Visible = true;
                    end = true;
                }
                i++;
            }
            if (!end)
            {
                lblErrorFirstName.Visible = false;
            }
        }

        private void txtLastName_Error(object sender, EventArgs e)
        {
            int i = 0;
            bool end = false;

            if (txtLastName.Text.Length >= 50)
            {
                lblErrorLastName.Text = "Error: Length of last name has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorLastName.Visible = true;
                end = true;
            }
            else if (txtLastName.Text.Length == 0)
            {

                lblErrorLastName.Text = "Error: Last name is a required field.";
                lblErrorLastName.Visible = true;
                end = true;
            }
            while (i < txtLastName.Text.Length && !end)
            {
                if (char.IsNumber(txtLastName.Text[i]))
                {
                    lblErrorLastName.Text = "Error: Numbers are not allowed in last name.";
                    lblErrorLastName.Visible = true;
                    end = true;
                }
                i++;
            }
            if (!end)
            {
                lblErrorLastName.Visible = false;
            }
        }

        private void txtCreditLimit_Error(object sender, EventArgs e)
        {
            int i = 0;
            bool end = false;
            int dotIndex = txtTotalCreditLimit.Text.IndexOf(".");
            if (dotIndex == -1 && txtTotalCreditLimit.Text.Length > 10)
            {
                lblErrorTotalCreditLimit.Text = "Error: Credit limit can only be up to 10 digits long.";
                lblErrorTotalCreditLimit.Visible = true;
                end = true;
            }
            else if (dotIndex != -1 && txtTotalCreditLimit.Text.Length > 10)
            {
                lblErrorTotalCreditLimit.Text = "Error: Credit limit can only be up to 10 digits long.";
                lblErrorTotalCreditLimit.Visible = true;
                end = true;
            }
            while (i < txtTotalCreditLimit.Text.Length && !end)
            {
                if (!char.IsControl(txtTotalCreditLimit.Text[i]) && !char.IsDigit(txtTotalCreditLimit.Text[i]) && txtTotalCreditLimit.Text[i] != '.')
                {
                    lblErrorTotalCreditLimit.Text = "Error: Only numbers and a point '.' allowed in credit limit.";
                    lblErrorTotalCreditLimit.Visible = true;
                    end = true;
                }


                i++;
            }

            if (txtTotalCreditLimit.Text.IndexOf(".") != txtTotalCreditLimit.Text.LastIndexOf(".") && !end)
            {
                lblErrorTotalCreditLimit.Text = "Error: Only one point '.' allowed in credit limit.";
                lblErrorTotalCreditLimit.Visible = true;
                end = true;
            }
            else if (dotIndex != -1 && txtTotalCreditLimit.Text.Substring(dotIndex).Length > 3 && !end)
            {
                lblErrorTotalCreditLimit.Text = "Error: Only two decimal places allowed in credit limit.";
                lblErrorTotalCreditLimit.Visible = true;
                end = true;
            }
            if (!end)
            {
                lblErrorTotalCreditLimit.Visible = false;
            }
        }

        private void txtCreditLimit_KeyPress(object sender, KeyPressEventArgs e)
        {

            int i = (sender as TextBox).Text.IndexOf('.');
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                lblErrorTotalCreditLimit.Text = "Error: Only numbers and a point '.' allowed in credit limit.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else if (e.KeyChar == '.' && i > -1)
            {
                lblErrorTotalCreditLimit.Text = "Error: Only one point '.' allowed in credit limit.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else if (i != -1 && txtTotalCreditLimit.SelectionStart > i && txtTotalCreditLimit.Text.Substring(i).Length >= 3 && !char.IsControl(e.KeyChar))
            {
                lblErrorTotalCreditLimit.Text = "Error: Only two decimal places allowed in credit limit.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else if (i == -1 && txtTotalCreditLimit.Text.Length > 10 && !char.IsControl(e.KeyChar))
            {
                lblErrorTotalCreditLimit.Text = "Error: Total credit limit has been exceeded.\nIt can only be up to 10 digits long.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else if (i != -1 && txtTotalCreditLimit.Text.Length > 10 && !char.IsControl(e.KeyChar))
            {
                lblErrorTotalCreditLimit.Text = "Error: Total credit limit has been exceeded.\nIt can only be up to 10 digits long.";
                lblErrorTotalCreditLimit.Visible = true;
                e.Handled = true;
            }
            else
            {
                lblErrorTotalCreditLimit.Visible = false;
            }

        }
        private void txtPostalCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (txtPostalCode.Text.Length >= 4 && !char.IsControl(e.KeyChar))
            {
                lblErrorPostalCode.Text = "Error: Postal code can only be up to 4 digits long.";
                lblErrorPostalCode.Visible = true;
                e.Handled = true;
            }

            else if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                lblErrorPostalCode.Text = "Error: Only numbers allowed in postal code.";
                lblErrorPostalCode.Visible = true;
                e.Handled = true;
            }
            else
            {
                lblErrorPostalCode.Visible = false;
            }

        }

        private void txtPostalCode_Error(object sender, EventArgs e)
        {
            bool end = false;
            int i = 0;
            if (txtPostalCode.Text.Length > 4)
            {
                lblErrorPostalCode.Text = "Error: Postal code can only be up to 4 digits long.";
                lblErrorPostalCode.Visible = true;
                end = true;
            }
            while (i < txtPostalCode.Text.Length && !end)
            {
                if (!char.IsDigit(txtPostalCode.Text[i]))
                {

                    lblErrorPostalCode.Text = "Error: Only numbers allowed in postal code.";
                    lblErrorPostalCode.Visible = true;
                    end = true;
                }
                i++;
            }

            if (!end)
            {
                lblErrorPostalCode.Visible = false;
            }


        }

        private void txtStreet_Error(object sender, EventArgs e)
        {
            if (txtStreet.Text.Length >= 50)
            {
                lblErrorStreet.Text = "Error: Length of street has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorStreet.Visible = true;
            }
            else
            {
                lblErrorStreet.Visible = false;
            }
        }

        private void txtSuburb_Error(object sender, EventArgs e)
        {
            if (txtSuburb.Text.Length >= 50)
            {
                lblErrorSuburb.Text = "Error: Length of suburb has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorSuburb.Visible = true;
            }
            else
            {
                lblErrorSuburb.Visible = false;
            }
        }

        private void txtTown_Error(object sender, EventArgs e)
        {
            if (txtTown.Text.Length >= 50)
            {
                lblErrorTown.Text = "Error: Length of town has been exceeded.\nIt only be up to 50 characters long.";
                lblErrorTown.Visible = true;
            }
            else
            {
                lblErrorTown.Visible = false;
            }
        }

        private void txtCity_Error(object sender, EventArgs e)
        {
            if (txtCity.Text.Length >= 50)
            {
                lblErrorCity.Text = "Error: Length of city has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorCity.Visible = true;
            }
            else
            {
                lblErrorCity.Visible = false;
            }
        }

        private void txtProvince_Error(object sender, EventArgs e)
        {

            if (txtProvince.Text.Length >= 50)
            {
                lblErrorProvince.Text = "Error: Length of province has been exceeded.\nIt can only be up to 50 characters long.";
                lblErrorProvince.Visible = true;
            }
            else
            {
                lblErrorProvince.Visible = false;
            }

        }

        #endregion

        #region Buttons & Checkbox
        private void chbModifyCreditLimit_CheckedChanged(object sender, EventArgs e)
        {
            if (chbModifyTotalCreditLimit.Checked)
            {
                txtTotalCreditLimit.ReadOnly = false;
            }
            else
            {
                txtTotalCreditLimit.ReadOnly = true;
            }
        }

        private void btnCreateCustomer_Click(object sender, EventArgs e)
        {
            if (isValidCustomerDetails())
            {
                Customer customer = new Customer();
                if (CreateNewCustomer(customer))
                {
                    customerManagementController.AddCustomer(customer);
                    customerManagementController.Customer = customer;
                    this.Hide();
                    MessageBox.Show("Customer has been created successfully!" + "\n" + "Please inform the customer of their customer number: " + customerManagementController.Customer.ID, "New Customer");
                    this.Close();
                }
            }
            else
            {
                lblErrorCreateCustomer.Text = "Error: Customer could not be created. Please fix above format field errors.";
                lblErrorCreateCustomer.Visible = true;
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to cancel creating a customer?", "Confirm Cancel Creating Customer", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        #endregion
    }
}
