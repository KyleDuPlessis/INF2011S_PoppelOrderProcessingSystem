﻿namespace Poppel.PresentationLayer
{
    partial class PickingList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPickingList = new System.Windows.Forms.Label();
            this.clnPickingListDate = new System.Windows.Forms.MonthCalendar();
            this.lstPickingList = new System.Windows.Forms.ListView();
            this.btnCancel = new System.Windows.Forms.Button();
            this.lblErrorPickingList = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.pbPoppelLogo = new System.Windows.Forms.PictureBox();
            this.lblGeneratedOn = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPickingList
            // 
            this.lblPickingList.AutoSize = true;
            this.lblPickingList.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.lblPickingList.Font = new System.Drawing.Font("Poor Richard", 21.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPickingList.ForeColor = System.Drawing.Color.Orchid;
            this.lblPickingList.Location = new System.Drawing.Point(305, 49);
            this.lblPickingList.Name = "lblPickingList";
            this.lblPickingList.Size = new System.Drawing.Size(154, 33);
            this.lblPickingList.TabIndex = 14;
            this.lblPickingList.Text = "Picking List";
            // 
            // clnPickingListDate
            // 
            this.clnPickingListDate.Location = new System.Drawing.Point(245, 211);
            this.clnPickingListDate.Margin = new System.Windows.Forms.Padding(7, 7, 7, 7);
            this.clnPickingListDate.Name = "clnPickingListDate";
            this.clnPickingListDate.TabIndex = 20;
            this.clnPickingListDate.DateSelected += new System.Windows.Forms.DateRangeEventHandler(this.clnPickDate_Click);
            // 
            // lstPickingList
            // 
            this.lstPickingList.Location = new System.Drawing.Point(9, 167);
            this.lstPickingList.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lstPickingList.Name = "lstPickingList";
            this.lstPickingList.Size = new System.Drawing.Size(719, 312);
            this.lstPickingList.TabIndex = 21;
            this.lstPickingList.UseCompatibleStateImageBehavior = false;
            this.lstPickingList.Visible = false;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(567, 487);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(81, 40);
            this.btnCancel.TabIndex = 29;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lblErrorPickingList
            // 
            this.lblErrorPickingList.AutoSize = true;
            this.lblErrorPickingList.ForeColor = System.Drawing.Color.Red;
            this.lblErrorPickingList.Location = new System.Drawing.Point(353, 82);
            this.lblErrorPickingList.Name = "lblErrorPickingList";
            this.lblErrorPickingList.Size = new System.Drawing.Size(40, 13);
            this.lblErrorPickingList.TabIndex = 36;
            this.lblErrorPickingList.Text = "<error>";
            this.lblErrorPickingList.Visible = false;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(655, 487);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 40);
            this.btnReset.TabIndex = 37;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // pbPoppelLogo
            // 
            this.pbPoppelLogo.Image = global::Poppel.Properties.Resources.poppel_logo3;
            this.pbPoppelLogo.Location = new System.Drawing.Point(12, 12);
            this.pbPoppelLogo.Name = "pbPoppelLogo";
            this.pbPoppelLogo.Size = new System.Drawing.Size(108, 83);
            this.pbPoppelLogo.TabIndex = 51;
            this.pbPoppelLogo.TabStop = false;
            // 
            // lblGeneratedOn
            // 
            this.lblGeneratedOn.AutoSize = true;
            this.lblGeneratedOn.Location = new System.Drawing.Point(58, 141);
            this.lblGeneratedOn.Name = "lblGeneratedOn";
            this.lblGeneratedOn.Size = new System.Drawing.Size(77, 13);
            this.lblGeneratedOn.TabIndex = 53;
            this.lblGeneratedOn.Text = "Generated On:";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Location = new System.Drawing.Point(147, 141);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(42, 13);
            this.lblDate.TabIndex = 55;
            this.lblDate.Text = "<Date>";
            // 
            // PickingList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Poppel.Properties.Resources.poppel_logo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.CancelButton = this.btnCancel;
            this.ClientSize = new System.Drawing.Size(685, 389);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblGeneratedOn);
            this.Controls.Add(this.pbPoppelLogo);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.lblErrorPickingList);
            this.Controls.Add(this.clnPickingListDate);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.lstPickingList);
            this.Controls.Add(this.lblPickingList);
            this.Name = "PickingList";
            this.Text = "Picking List";
            ((System.ComponentModel.ISupportInitialize)(this.pbPoppelLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPickingList;
        private System.Windows.Forms.MonthCalendar clnPickingListDate;
        private System.Windows.Forms.ListView lstPickingList;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Label lblErrorPickingList;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.PictureBox pbPoppelLogo;
        private System.Windows.Forms.Label lblGeneratedOn;
        private System.Windows.Forms.Label lblDate;
    }
}