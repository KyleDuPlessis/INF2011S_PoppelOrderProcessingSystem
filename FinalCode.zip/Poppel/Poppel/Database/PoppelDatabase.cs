﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

//namespaces
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using Poppel.Domain;
using Poppel.Order;
using Poppel.Report;
using System.Windows.Forms;


namespace Poppel.Database
{
    public class PoppelDatabase : Database
    {
        #region Data Members
        private Collection<Category> categories;
        private Collection<StockItem> items;
        #endregion

        public bool DoesKeyExist(string id)
        {
            SqlDataReader reader;
            SqlCommand command;
            bool exists = false;
            try
            {
                command = new SqlCommand("SELECT TOP 1 customerID FROM Customer WHERE customerID = '" + id + "'", cnMain);
                cnMain.Open();             
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();                       
                if (reader.HasRows)
                {
                    exists = true;
                }
                reader.Close();   
                cnMain.Close();  
                return exists;
            }
            catch (Exception ex)
            {
                
                cnMain.Close();
                Console.Write(ex.ToString());
                return true;
            }

        }

        public void AddCustomer(Customer customer)
        {
            string sqlString = "";
            sqlString = "INSERT INTO Customer(customerID,customerFirstName,customerLastName,customerPhoneNumber,customerEmailAddress,customerCreditRemaining,customerTotalCreditLimit,customerStreet,customerTown,customerSuburb,customerCity,customerProvince,customerPostalCode) VALUES ('" + customer.ID.Trim() + "','" + customer.FirstName.Trim() + "','" + customer.LastName.Trim() + "','" + customer.PhoneNumber.Trim() + "','" + customer.EmailAddress.Trim() + "'," + customer.Credit.ToString() + "," + customer.CreditLimit.ToString() + ",'" + customer.DeliveryAddress[0].Trim() + "','" + customer.DeliveryAddress[1] + "','" + customer.DeliveryAddress[2] + "','" + customer.DeliveryAddress[3] + "','" + customer.DeliveryAddress[4] + "','" + customer.DeliveryAddress[5] + "')";

            UpdateDataSource(new SqlCommand(sqlString, cnMain));
        }

        
        public Customer ReadCustomersByCustomerNumber(string id)
        {
            SqlDataReader reader;
            SqlCommand command;
            try
            {
                Customer customer = null;
                command = new SqlCommand("SELECT * FROM Customer WHERE customerID = '" + id + "'", cnMain);
                cnMain.Open();             
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();                       
                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        customer = CreateCustomer(reader);
                    }
                }
                reader.Close();    
                cnMain.Close();  
                return customer;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
               
                cnMain.Close();
                Console.Write(ex.ToString());
                return null;
            }
        }

        public Collection<OrderItem> ReadProducts()
        {
            Collection<OrderItem> products = new Collection<OrderItem>();
            SqlDataReader reader;
            SqlCommand command;
            try
            {
                command = new SqlCommand("SELECT * FROM Product", cnMain);
                cnMain.Open();            
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();                     
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        OrderItem orderItem = new OrderItem();
                        orderItem.Product = CreateProduct(reader);
                        products.Add(orderItem);

                    }
                }
                reader.Close();   
                cnMain.Close();  
                ReadCategories(products);
                foreach (OrderItem product in products)
                {
                    SetStockCount(product.Product);
                }
                return products;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                
                cnMain.Close();
                Console.Write(ex.ToString());
                return null;
            }
        }

        public Collection<ReportItem> ReadOrderItem(DateTime date)
        {
            Collection<ReportItem> products = new Collection<ReportItem>();
            SqlDataReader reader;
            SqlCommand command;
            try
            {
                command = new SqlCommand("SELECT orderItemID FROM OrderItem", cnMain);
                cnMain.Open();             
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                int orderId = -1;
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int orderItem_id = reader.GetInt32(0);
                        int stockItem_id;
                        SqlConnection connection = NewConnection();
                        SqlCommand currentCommand = new SqlCommand("SELECT stockItemID,itemQuantity FROM OrderStockItem WHERE orderItemID = " + orderItem_id, connection);
                        connection.Open();
                        currentCommand.CommandType = CommandType.Text;
                        SqlDataReader reader2 = currentCommand.ExecuteReader();
                        if (reader2.HasRows)
                        {
                            while (reader2.Read())
                            {
                                ReportItem orderItem = new ReportItem();
                                

                                stockItem_id = reader2.GetInt32(0);
                                int quantity = reader2.GetInt32(1);

                                SqlConnection connection2 = NewConnection();
                                SqlCommand currentCommand2 = new SqlCommand("SELECT productReference FROM StockItem WHERE stockItemID = " + stockItem_id , connection2);
                                connection2.Open();
                                currentCommand2.CommandType = CommandType.Text;
                                SqlDataReader reader3 = currentCommand2.ExecuteReader();
                                int product_id=-1;
                                if (reader3.HasRows)
                                {
                                    if(reader3.Read())
                                    {
                                        product_id = reader3.GetInt32(0);
                                        orderItem.ProductID = product_id;
                                    }
                                }
                                reader3.Close();
                                connection2.Close();

                                orderId = this.GetOrderNumber(orderItem_id);
                                orderItem.OrderID = orderId + "";
                                orderItem.Quantity = "" + quantity;
                                orderItem.Description = this.GetDescription(product_id);
                                orderItem.RackNumber = this.GetRackNumber(stockItem_id);

                                if (this.GetOrderDate(orderId,date))
                                {
                                    products.Add(orderItem);
                                }                               
                            }
                        }
                        reader2.Close();
                        connection.Close();
                    }
                }
                reader.Close();  
                cnMain.Close();  

                return products;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                
                cnMain.Close();
                Console.Write(ex.ToString());
                return null;
            }
        }

        public int GetOrderNumber(int ID)
        {
            SqlDataReader reader;
            SqlCommand command;

            try
            {
                SqlConnection connection = NewConnection();
                command = new SqlCommand("SELECT orderID FROM OrderItem WHERE orderItemID = " + ID + ";", connection);
                connection.Open();             
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                int number = 0;
                
                if (reader.HasRows)
                {
                    reader.Read();
                    number = reader.GetInt32(0);
                }
                reader.Close();   
                connection.Close(); 
                return number;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
               
                cnMain.Close();
                Console.Write(ex.ToString());
            }
            return 0;
        }

        public bool GetOrderDate(int ID, DateTime checkDate)
        {
            SqlDataReader reader;
            SqlCommand command;
            try
            {
                SqlConnection conn = NewConnection();
                command = new SqlCommand("SELECT deliveryID FROM Delivery WHERE orderID = " + ID, conn);
                conn.Open();            
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                bool found = false;
                
                if (reader.HasRows)
                {
                    reader.Read();
                    int delivery_id =reader.GetInt32(0);
                    SqlConnection connection = NewConnection();
                    SqlCommand currentCommand = new SqlCommand("SELECT deliveryDate FROM DeliveryDate WHERE deliveryID = " + delivery_id, connection);
                    connection.Open();
                    currentCommand.CommandType = CommandType.Text;
                    SqlDataReader reader2 = currentCommand.ExecuteReader();
                    
                    if(reader2.HasRows)
                    {
                        while (!found && reader2.Read())
                        {
                            DateTime date = reader2.GetDateTime(0);
                            if(date.ToShortDateString().Equals(checkDate.ToShortDateString()))
                            {
                                found = true;
                            }
                        }
                    }
                    reader2.Close();
                    connection.Close();
                }
                reader.Close();   
                conn.Close();  
                return found;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
               
                cnMain.Close();
                Console.Write(ex.ToString());
            }
            return false;
        }

        private void ReadCategories(Collection<OrderItem> products)
        {
            SqlDataReader reader;
            SqlCommand command;
            try
            {
                if (categories == null)
                {
                    ReadCategories();
                }
                foreach (OrderItem product in products)
                {
                    command = new SqlCommand("SELECT categoryID FROM ProductCategory WHERE productID=" + product.Product.ID, cnMain);
                    cnMain.Open();             
                    command.CommandType = CommandType.Text;
                    reader = command.ExecuteReader();
                   
                    if (reader.HasRows)
                    {
                        product.Product.Categories = new Collection<Category>();
                        while (reader.Read())
                        {
                            int category_id = reader.GetInt32(0);
                            Boolean added = false;
                            int index = 0;
                            while (!added && index < categories.Count)
                            {
                                if (categories[index].ID == category_id)
                                {
                                    product.Product.Categories.Add(categories[index]);
                                    added = true;
                                }
                                index++;
                            }
                        }
                    }
                    reader.Close();   
                    cnMain.Close(); 
                }
            }
            catch (Exception ex)
            {
               
                cnMain.Close();
                Console.Write(ex.ToString());
            }
        }

        private Product CreateProduct(SqlDataReader reader)
        {
            Product product = new Product();
            product.ID = reader.GetInt32(0);
            product.Description = reader.GetString(1).Trim();
            product.Price = reader.GetDecimal(2);
            product.ProductCode = reader.GetString(3).Trim();
            return product;
        }

        private void SetStockCount(Product product)
        {
            SqlDataReader reader;
            SqlCommand command;
            try
            {
                DateTime check = DateTime.Now.AddMonths(1);
                command = new SqlCommand("SELECT SUM(stockItemNumberInStock) AS number_in_stock FROM StockItem WHERE productReference = " + product.ID + " AND DATEDIFF(day, '" + check.ToString() + "',stockItemExpiryDate) >= 0", cnMain);
                cnMain.Open();            
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();                       
                if (reader.HasRows)
                {
                    if (reader.Read())
                    {
                        if (reader.IsDBNull(0))
                        {
                            product.NumberInStock = 0;
                        }
                        else
                        {
                            product.NumberInStock = reader.GetInt32(0);
                        }

                    }
                }
                reader.Close();  
                cnMain.Close();  
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
              
                cnMain.Close();
                Console.Write(ex.ToString());
            }
        }

        public void EditCustomer(Customer customer)
        {
            string sqlString = "";
            sqlString = "Update Customer Set customerFirstName = '" + customer.FirstName.Trim() + "',customerLastName = '" + customer.LastName.Trim() + "',customerPhoneNumber = '" + customer.PhoneNumber.Trim() + "',customerEmailAddress = '" + customer.EmailAddress.Trim() + "',customerCreditRemaining = " + customer.Credit.ToString() + ",customerTotalCreditLimit = " + customer.CreditLimit.ToString() + ",customerStreet = '" + customer.DeliveryAddress[0].Trim() + "',customerTown = '" + customer.DeliveryAddress[1] + "',customerSuburb = '" + customer.DeliveryAddress[2] + "',customerCity = '" + customer.DeliveryAddress[3] + "',customerProvince = '" + customer.DeliveryAddress[4] + "',customerPostalCode = '" + customer.DeliveryAddress[5] + "' WHERE (customerID = '" + customer.ID.Trim() + "')";

            UpdateDataSource(new SqlCommand(sqlString, cnMain));
        }

        
        private Customer CreateCustomer(SqlDataReader reader)
        {

            Customer customer = new Customer();
            customer.ID = reader.GetString(0).Trim();
            customer.FirstName = reader.GetString(1).Trim();
            customer.LastName = reader.GetString(2).Trim();
            if (!reader.IsDBNull(3))
            {
                customer.PhoneNumber = reader.GetString(3).Trim();
            }
            if (!reader.IsDBNull(4))
            {
                customer.EmailAddress = reader.GetString(4).Trim();
            }
            
            string[] address = new string[6];

            if (!reader.IsDBNull(5))
            {
                address[0] = reader.GetString(5).Trim();
            }
            if (!reader.IsDBNull(6))
            {
                address[1] = reader.GetString(6).Trim();
            }
            if (!reader.IsDBNull(7))
            {
                address[2] = reader.GetString(7).Trim();
            }
            if (!reader.IsDBNull(8))
            {
                address[3] = reader.GetString(8).Trim();
            }
            if (!reader.IsDBNull(9))
            {
                address[4] = reader.GetString(9).Trim();
            }
            if (!reader.IsDBNull(10))
            {
                address[5] = reader.GetString(10).Trim();
            }
            for (int i = 0; i < address.Length; i++)
            {
                if (address[i] == null)
                {
                    address[i] = "";
                }
            }

            customer.Credit = reader.GetDecimal(12);
            customer.CreditLimit = reader.GetDecimal(11);
            customer.DeliveryAddress = address;
            return customer;
        }

        public Collection<Category> ReadCategories()
        {
            SqlDataReader reader;
            SqlCommand command;
            Collection<Category> categories;
            try
            {
                command = new SqlCommand("SELECT * FROM Category", cnMain);
                cnMain.Open();             
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                categories = new Collection<Category>();
                
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Category category = new Category();
                        category.ID = reader.GetInt32(0);
                        category.Description = reader.GetString(1);
                        categories.Add(category);
                    }
                }
                reader.Close();  
                cnMain.Close();  
                this.categories = categories;
                return categories;
            }
            catch (Exception ex)
            {
                
                cnMain.Close();
                Console.Write(ex.ToString());
            }
            return null;
        }     

        public DateTime GetOrderDate(string id)
        {
            SqlDataReader reader;
            SqlCommand command;

            try
            {
                command = new SqlCommand("SELECT orderDatePlaced FROM Order WHERE orderID = '" + id + "';", cnMain);
                cnMain.Open();            
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                DateTime date = DateTime.Today;
               
                if (reader.HasRows)
                {
                    date = reader.GetDateTime(1);
                }
                reader.Close();   
                cnMain.Close();  
                return date;
            }
            catch (Exception ex)
            {
                
                cnMain.Close();
                Console.Write(ex.ToString());
            }
            return DateTime.Today;
        }

        public void RemoveOrder(string id)
        {
            SqlDataReader reader;
            SqlCommand command;

            try
            {
                command = new SqlCommand("DELETE FROM Order WHERE orderID = '" + id + "';", cnMain);
                cnMain.Open();             
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();

                reader.Close();  
                cnMain.Close(); 
            }
            catch (Exception ex)
            {
                
                cnMain.Close();
                Console.Write(ex.ToString());
            }
        }

        public string GetRackNumber(int id)
        {
            SqlDataReader reader;
            SqlCommand command;

            try
            {
                SqlConnection connection = NewConnection();
                command = new SqlCommand("SELECT stockItemRackNumber FROM StockItem WHERE stockItemID = " + id + ";", connection);
                connection.Open();            
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                string number = "";
                
                if (reader.HasRows)
                {
                    reader.Read();
                    number = reader.GetString(0);
                }
                reader.Close();  
                connection.Close();  
                return number + "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                
                Console.Write(ex.ToString());
            }
            return null;
        }

        public string GetQuantity(int id)
        {
            SqlDataReader reader;
            SqlCommand command;

            try
            {
                SqlConnection connection = NewConnection();
                command = new SqlCommand("SELECT productQuantity FROM OrderItem WHERE productID = " + id + ";", connection);
                connection.Open();             
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                int number = 0;
                
                if (reader.HasRows)
                {
                    number = reader.GetInt32(1);
                }
                reader.Close();  
                connection.Close();  
                return number + "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                
                Console.Write(ex.ToString());
            }
            return null;
        }

        public string GetDescription(int id)
        {
            SqlDataReader reader;
            SqlCommand command;
            
            try
            {
                SqlConnection connection = NewConnection();
                command = new SqlCommand("SELECT productDescription FROM Product WHERE productID = " + id + ";", connection);
                connection.Open();            
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                String descritpion = "";
                
                if (reader.HasRows)
                {
                    reader.Read();
                    descritpion = reader.GetString(0);
                }
                reader.Close();  
                connection.Close();  
                return descritpion;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
              
                Console.Write(ex.ToString());
            }
            return null;
        }

        public Collection<StockItem> ReadStock(string date)
        {
            SqlDataReader reader;
            SqlCommand command;
            Collection<StockItem> items;
            try
            {
                DateTime input;
                DateTime.TryParse(date, out input);
                command = new SqlCommand("SELECT * FROM StockItem WHERE DATEDIFF(day, stockItemExpiryDate,'" + input.ToString() + "') >= 0 ORDER BY stockItemRackNumber", cnMain);
                cnMain.Open();            
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                items = new Collection<StockItem>();
              
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        StockItem item = new StockItem();
                        item.ItemExpiryDate = reader.GetDateTime(1).ToShortDateString();
                        item.ItemRackNumber = reader.GetString(2);
                        item.ItemNumberInStock = reader.GetInt32(3) + "";
                        item.ProductReference = reader.GetInt32(4) + "";
                        SqlConnection connection = NewConnection();
                        SqlCommand command2 = new SqlCommand("SELECT productDescription FROM Product WHERE productID = " + item.ProductReference + ";", connection);
                        connection.Open();            
                        command2.CommandType = CommandType.Text;
                        SqlDataReader reader2 = command2.ExecuteReader();
                        String descritpion = "";
                        
                        if (reader2.HasRows)
                        {
                            reader2.Read();
                            descritpion = reader2.GetString(0);
                        }
                        reader2.Close();   
                        connection.Close(); 
                        item.ProductReference = descritpion;
                        items.Add(item);
                    }
                }
                reader.Close();  
                cnMain.Close(); 
                this.items = items;
                return items;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
               
                cnMain.Close();
                Console.Write(ex.ToString());
            }
            return null;
        }

        public Collection<RemoveOrderItem> GetOrders(string customerId)
        {
            SqlDataReader reader;
            SqlCommand command;
            Collection<RemoveOrderItem> oItems;
            try
            {
                command = new SqlCommand("SELECT orderID,orderDatePlaced FROM [Order] WHERE customerID = '"+customerId+"' AND orderStatus = 'Open'",cnMain);
                cnMain.Open();             
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                oItems = new Collection<RemoveOrderItem>();
               
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        RemoveOrderItem rm = new RemoveOrderItem();
                        rm.OrderNumber = reader.GetInt32(0)+"";
                        rm.OrderDatePlaced = reader.GetDateTime(1)+"";
                        oItems.Add(rm);
                    }
                }
                reader.Close();   
                cnMain.Close();  
                return oItems;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
              
                cnMain.Close();
                Console.Write(ex.ToString());
            }
            return null;
        }

        public Employee Login(string username, string password)
        {
            SqlDataReader reader;
            SqlCommand command;

            try
            {
                Employee employee = null;
                command = new SqlCommand("SELECT * FROM Employee WHERE employeeID = '" + username + "' AND employeePassword ='" + password + "'", cnMain);
                cnMain.Open();           
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();                      
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        employee = CreateEmployee(reader);
                    }
                }
                reader.Close();   
                cnMain.Close(); 
                return employee;
            }
            catch (Exception ex)
            {
                
                cnMain.Close();
                Console.Write(ex.ToString());
                return null;
            }
        }

        private Employee CreateEmployee(SqlDataReader reader)
        {

            Employee employee = new Employee();
            employee.ID = reader.GetString(0).Trim();
            employee.FirstName = reader.GetString(1).Trim();
            employee.LastName = reader.GetString(2).Trim();
            if (!reader.IsDBNull(3))
            {
                employee.PhoneNumber = reader.GetString(3).Trim();
            }
            if (!reader.IsDBNull(4))
            {
                employee.EmailAddress = reader.GetString(4).Trim();
            }
            string[] address = new string[6];

            if (!reader.IsDBNull(5))
            {
                address[0] = reader.GetString(5).Trim();
            }
            if (!reader.IsDBNull(6))
            {
                address[1] = reader.GetString(6).Trim();
            }
            if (!reader.IsDBNull(7))
            {
                address[2] = reader.GetString(7).Trim();
            }
            if (!reader.IsDBNull(8))
            {
                address[3] = reader.GetString(8).Trim();
            }
            if (!reader.IsDBNull(9))
            {
                address[4] = reader.GetString(9).Trim();
            }
            if (!reader.IsDBNull(10))
            {
                address[5] = reader.GetString(9).Trim();
            }
            for (int i = 0; i < address.Length; i++)
            {
                if (address[i] == null)
                {
                    address[i] = "";
                }
            }
            employee.DeliveryAddress = address;
            employee.Salary = reader.GetDecimal(13);
            employee.Position = reader.GetString(12);
            return employee;
        }

        public void WriteOrder(Order.Order order)
        {
            string sqlString = "";
            sqlString = "INSERT INTO [Order](orderDatePlaced,customerID,employeeID) OUTPUT INSERTED.orderID VALUES ('" + order.DateOrderPlaced.ToString() + "','" + order.Customer.ID.Trim() + "','" + order.Employee.ID + "')";
            

            SqlDataReader reader;
            SqlCommand command;
            try
            {
                command = new SqlCommand(sqlString, cnMain);
                cnMain.Open();           
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
               
                int id = -1;
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        id = reader.GetInt32(0);
                    }
                }
                reader.Close();   
                cnMain.Close();

                if (id != -1)
                    for (int i = 0; i < order.Products.Count; i++)
                    {
                        sqlString = "INSERT INTO [OrderItem](orderID,productQuantity) OUTPUT INSERTED.orderItemID VALUES (" + id + "," + order.Products[i].Quantity + ")";
                        cnMain.Open();
                        command = new SqlCommand(sqlString, cnMain);
                        command.CommandType = CommandType.Text;
                        reader = command.ExecuteReader();
                       
                        int orderItemId = -1;
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                orderItemId = reader.GetInt32(0);
                            }
                        }
                        cnMain.Close();
                        reader.Close();   

                        DateTime check = DateTime.Now;
                        check = check.AddMonths(1);
                        sqlString = "SELECT stockItemID,stockItemNumberInStock FROM StockItem WHERE DATEDIFF(day, '" + check.ToString() + "',stockItemExpiryDate) >= 0 AND productReference = " + order.Products[i].Product.ID + " AND stockItemNumberInStock>0 order by convert(datetime, stockItemExpiryDate, 103) ASC";
                        command = new SqlCommand(sqlString, cnMain);
                        cnMain.Open();            
                        command.CommandType = CommandType.Text;
                        reader = command.ExecuteReader();
                        
                        int stockItemID = -1;
                        bool done = false;
                        if (reader.HasRows)
                        {
                            int reduceCounter = order.Products[i].Quantity;
                            while (reader.Read() &&reduceCounter!=0)
                            {

                                stockItemID = reader.GetInt32(0);
                                int numInStock = reader.GetInt32(1);
                                int reductionAmount;
                                if (numInStock >= reduceCounter)
                                {
                                    done = true;
                                    reductionAmount = reduceCounter;
                                    reduceCounter -= reductionAmount;
                                }
                                else
                                {
                                    reductionAmount = numInStock;
                                    reduceCounter -= reductionAmount;
                                   
                                }
                                SqlConnection connection = NewConnection();

                                SqlCommand currentCommand = new SqlCommand("INSERT INTO OrderStockItem(orderItemID,stockItemID, itemQuantity) VALUES(" + orderItemId + "," + stockItemID + "," + reductionAmount + ")", connection);
                                currentCommand.CommandType = CommandType.Text;
                                connection.Open();
                                currentCommand.ExecuteNonQuery();
                                connection.Close();

                                currentCommand = new SqlCommand("Update StockItem Set stockItemNumberInStock = stockItemNumberInStock - " + reductionAmount + "WHERE stockItemID = " + stockItemID, connection);
                                currentCommand.CommandType = CommandType.Text;
                                connection.Open();
                                currentCommand.ExecuteNonQuery();

                                connection.Close();
                            }
                        }
                        reader.Close();   
                        cnMain.Close();                    
                    }

               
                cnMain.Open();
                command = new SqlCommand(sqlString, cnMain);
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                
                int deliveryId = -1;
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        deliveryId = reader.GetInt32(0);
                    }
                }
                cnMain.Close();
                reader.Close();

                cnMain.Close(); 
                 sqlString = "UPDATE CUSTOMER SET customerCreditRemaining = customerCreditRemaining + " + order.OrderPrice;
                        command = new SqlCommand(sqlString, cnMain);
                        cnMain.Open();           
                        command.ExecuteNonQuery();
                        cnMain.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
               
                cnMain.Close();
                Console.Write(ex.ToString());
            }
        }
     
        public void DeleteOrder(int orderId, string customerId)
        {
            string sqlString = "";
          
           

            SqlDataReader reader;
            SqlCommand command;
            try
            {

                sqlString = "SELECT productQuantity,orderItemID FROM OrderItem Where orderID = '" + orderId + "'";
                command = new SqlCommand(sqlString, cnMain);
                cnMain.Open();
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
                decimal payBack = 0;
                

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int product_quantity = reader.GetInt32(0);
                        int orderItem_id = reader.GetInt32(1);
                        SqlConnection connection = NewConnection();

                        SqlCommand currentCommand = new SqlCommand("SELECT stockItemID, itemQuantity FROM OrderStockItem WHERE orderItemID = " + orderItem_id, connection);
                        connection.Open();
                        currentCommand.CommandType = CommandType.Text;
                        SqlDataReader reader2 = currentCommand.ExecuteReader();
                        int stockItem_id=-1;
                        int item_quantity;
                        if (reader2.HasRows)
                        {
                            while (reader2.Read())
                            {
                                stockItem_id = reader2.GetInt32(0);
                                item_quantity = reader2.GetInt32(1);
                                SqlConnection updateStockConnection = NewConnection();

                                SqlCommand updateStockCommand = new SqlCommand("UPDATE StockItem Set stockItemNumberInStock = stockItemNumberInStock + " + item_quantity + " WHERE stockItemID = " + stockItem_id, updateStockConnection);
                                updateStockConnection.Open();
                                updateStockCommand.CommandType = CommandType.Text;
                                updateStockCommand.ExecuteNonQuery();
                                updateStockConnection.Close();
                            }
                        }
                        connection.Close();
                        reader2.Close();
                        currentCommand = new SqlCommand("DELETE FROM OrderStockItem WHERE orderItemID = " + orderItem_id, connection);
                        connection.Open();
                        currentCommand.CommandType = CommandType.Text;
                        currentCommand.ExecuteNonQuery();
                        connection.Close();

                        currentCommand = new SqlCommand("SELECT productReference FROM StockItem WHERE stockItemID = " + stockItem_id, connection);
                        connection.Open();
                        currentCommand.CommandType = CommandType.Text;
                        reader2 = currentCommand.ExecuteReader();
                        int product_ref = -1;
                        if(reader2.HasRows)
                        {
                            reader2.Read();
                            product_ref = reader2.GetInt32(0);
                        }
                        reader2.Close();
                        connection.Close();
                        currentCommand = new SqlCommand("SELECT productPrice FROM Product WHERE productID = " + product_ref, connection);
                        connection.Open();
                        currentCommand.CommandType = CommandType.Text;
                        reader2 = currentCommand.ExecuteReader();
                        if (reader2.HasRows)
                        {
                            reader2.Read();
                            payBack = payBack + (reader2.GetDecimal(0)*product_quantity);
                        }
                        reader2.Close();
                        connection.Close();
                    }
                }

                cnMain.Close();
                reader.Close();  

                
                sqlString = "UPDATE CUSTOMER SET customerCreditRemaining = customerCreditRemaining - " + payBack+" Where customerID = '"+customerId+"'";
                command = new SqlCommand(sqlString, cnMain);
                cnMain.Open();          
                command.CommandType = CommandType.Text;
                command.ExecuteNonQuery();
                cnMain.Close();

                sqlString = "DELETE FROM OrderItem Where orderID = " + orderId;
                command = new SqlCommand(sqlString, cnMain);
                cnMain.Open();           
                command.CommandType = CommandType.Text;
                command.ExecuteNonQuery();
                cnMain.Close();
                sqlString = "SELECT deliveryID FROM Delivery Where orderID = '" + orderId + "'";
                command = new SqlCommand(sqlString, cnMain);
                cnMain.Open();
                command.CommandType = CommandType.Text;
                reader = command.ExecuteReader();
               

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int deliveryId = reader.GetInt32(0);
                        SqlConnection connection = NewConnection();

                        SqlCommand currentCommand = new SqlCommand("DELETE FROM DeliveryDate WHERE deliveryID = " + deliveryId, connection);
                        connection.Open();
                        currentCommand.CommandType = CommandType.Text;
                        currentCommand.ExecuteNonQuery();
                        connection.Close();
                    }
                }
                reader.Close();
                cnMain.Close();
                sqlString = "DELETE FROM Delivery Where orderID = " + orderId;
                command = new SqlCommand(sqlString, cnMain);
                cnMain.Open();          
                command.CommandType = CommandType.Text;
                command.ExecuteNonQuery();
                cnMain.Close();

                sqlString = "DELETE FROM [Order] Where orderID = '" + orderId + "'";
                command = new SqlCommand(sqlString, cnMain);
                cnMain.Open();            
                command.CommandType = CommandType.Text;
                command.ExecuteNonQuery();
                cnMain.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" + ex.StackTrace);
                
                cnMain.Close();
                Console.Write(ex.ToString());
            }
        }   
    }
}
