﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

//Name Spaces
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.Windows.Forms;
using Poppel.Properties;

namespace Poppel.Database
{
    public class Database
    {
        private string strConn = Settings.Default.PoppelDatabaseConnectionString;
        protected SqlConnection cnMain;

        public Database()
        {
            try
            {
                //Create a connection
                cnMain = new SqlConnection(strConn);
            }
            catch (SystemException e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message, "Error");
                return;
            }
        }

        protected SqlConnection NewConnection()
        {
            return new SqlConnection(strConn);
        }

        protected bool UpdateDataSource(SqlCommand currentCommand)
        {
            bool success;
            try
            {
                //open the connection
                cnMain.Open();

                currentCommand.CommandType = CommandType.Text;
                currentCommand.ExecuteNonQuery();

                //close the connection
                cnMain.Close();
                success = true;
            }
            catch (Exception errObj)
            {
                MessageBox.Show(errObj.Message + "  " + errObj.StackTrace);
                cnMain.Close();
                success = false;
            }
            finally
            {
            }
            return success;
        }
    }
}
