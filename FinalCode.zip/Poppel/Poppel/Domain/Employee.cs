﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.Domain
{
    public class Employee : Person
    {
        #region Data Members
        private decimal salary;
        private string position;
        #endregion

        #region Properties
        public decimal Salary
        {
            get { return salary; }
            set { salary = value; }
        }

        public string Position
        {
            get { return position; }
            set { position = value; }
        }
        #endregion
    }
}
