﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.Domain
{
    public abstract class Person
    {
        #region Data Members
        private string firstName;
        private string lastName;
        private string id;
        private string phoneNumber;
        private string emailAddress;
        private string[] deliveryAddress;
        //constant
        public static readonly int ADDRESS_LENGTH = 6;
        #endregion

        #region Constructors
        public Person()
        {
            deliveryAddress = new string[6];
        }
        #endregion

        #region Properties
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }

        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string ID
        {
            get { return id; }
            set { id = value; }
        }

        public string PhoneNumber
        {
            get { return phoneNumber; }
            set { phoneNumber = value; }
        }

        public string EmailAddress
        {
            get { return emailAddress; }
            set { emailAddress = value; }
        }

        public string[] DeliveryAddress
        {
            get { return deliveryAddress; }
            set { deliveryAddress = value; }
        }
        #endregion

        #region Utility      
        public string DeliveryAddressToString()
        {
            if (deliveryAddress == null)
            {
                return null;
            }

            string tempDeliveryAddress = deliveryAddress[0];

            for (int i = 1; i < deliveryAddress.Length-1; i++)
            {
                if(deliveryAddress[i] != null && !deliveryAddress[i].Equals(""))
                {
                    tempDeliveryAddress += ", " + deliveryAddress[i];
                }
             
            }

            return tempDeliveryAddress;
        }

        public string DeliveryAddressMultilineToString()
        {
            if (deliveryAddress == null)
            {
                return null;
            }

            string tempDeliveryAddress = deliveryAddress[0];

            for (int i = 1; i < deliveryAddress.Length - 1; i++)
            {
                if (deliveryAddress[i] != null && !deliveryAddress[i].Equals(""))
                {
                    tempDeliveryAddress += "\r\n" + deliveryAddress[i];
                }
            }
            return tempDeliveryAddress;
        }

        public static string FormatPhoneNumber(string phoneNum)
        {
            if (phoneNum == null || phoneNum.Length != 10)
            {
                return null;
            }

            return "("+ phoneNum.Substring(0,3)+") "+ phoneNum.Substring(3,3)+"-"+ phoneNum.Substring(6);
        }

        public static string UnFormatPhoneNumber(string phoneNum)
        {

            if(phoneNum == null || phoneNum.Length!=14)
            {
                return null;
            }

            return phoneNum.Substring(1, 3) + phoneNum.Substring(6, 3) + phoneNum.Substring(10, 4);
        }

        public string NameToString()
        {
            return firstName + " " + lastName; 
        }
        #endregion
    }
}
