﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Poppel.Domain
{
    public class Category
    {
        #region Data Members
        private int id;
        private string description;
        #endregion
                
        #region Properties
        public int ID
        {
            get { return id; }
            set { id = value; }
        }
       
        public string Description
        {
            get { return description; }
            set { description = value; }
        }
        #endregion

        public override string ToString()
        {
            return description;
        }
    }
}
